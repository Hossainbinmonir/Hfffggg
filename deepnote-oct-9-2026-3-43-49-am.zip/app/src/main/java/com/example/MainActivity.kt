package com.example

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.alarm.NotificationHelper
import com.example.ui.AppScreen
import com.example.ui.MainViewModel
import com.example.ui.chat.ChatScreen
import com.example.ui.home.HomeScreen
import com.example.ui.lock.PinLockScreen
import com.example.ui.reminder.ReminderListScreen
import com.example.ui.theme.DeepNoteTheme
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        NotificationHelper.createNotificationChannel(this)

        handleIntent(intent)

        setContent {
            val appTheme by viewModel.appTheme.collectAsState()
            val accentIndex by viewModel.accentIndex.collectAsState()

            MyApplicationTheme(
                darkTheme = appTheme == "dark",
                accentIndex = accentIndex
            ) {
                MainAppContainer(viewModel = viewModel)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        val openCatId = intent?.getStringExtra("OPEN_CATEGORY_ID")
        if (!openCatId.isNullOrBlank()) {
            viewModel.navigateToChat(openCatId)
        }
    }
}

@Composable
fun MainAppContainer(viewModel: MainViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val currentScreen by viewModel.currentScreen.collectAsState()
    val currentCategory by viewModel.currentCategory.collectAsState()
    val toastMessage by viewModel.toastMessage.collectAsState()

    val userPin by viewModel.userPin.collectAsState()
    val isUnlocked by viewModel.isUnlocked.collectAsState()

    // Import confirmation dialog state
    var pendingImportJson by remember { mutableStateOf<String?>(null) }
    var pendingImportCategoryCount by remember { mutableStateOf(0) }
    var showImportConfirmDialog by remember { mutableStateOf(false) }

    // Request Notifications Permission Launcher
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.showToast("নোটিফিকেশন চালু হয়েছে")
        }
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Toast feedback
    LaunchedEffect(toastMessage) {
        toastMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.clearToast()
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = DeepNoteTheme.colors.bgPrimary
    ) {
        // If PIN is enabled and not unlocked yet
        if (userPin != null && !isUnlocked) {
            PinLockScreen(
                onUnlockSuccess = {
                    viewModel.unlock(userPin!!)
                },
                onVerifyPin = { pin ->
                    viewModel.unlock(pin)
                }
            )
        } else {
            // Cubic bezier(0.2, 0.8, 0.2, 1) transition: 300ms
            val customEasing = CubicBezierEasing(0.2f, 0.8f, 0.2f, 1f)

            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = {
                    if (targetState == AppScreen.CHAT || targetState == AppScreen.REMINDERS) {
                        slideInHorizontally(
                            animationSpec = tween(300, easing = customEasing),
                            initialOffsetX = { fullWidth -> fullWidth }
                        ) togetherWith slideOutHorizontally(
                            animationSpec = tween(300, easing = customEasing),
                            targetOffsetX = { fullWidth -> -fullWidth / 3 }
                        )
                    } else {
                        slideInHorizontally(
                            animationSpec = tween(300, easing = customEasing),
                            initialOffsetX = { fullWidth -> -fullWidth / 3 }
                        ) togetherWith slideOutHorizontally(
                            animationSpec = tween(300, easing = customEasing),
                            targetOffsetX = { fullWidth -> fullWidth }
                        )
                    }
                },
                label = "screen_transition"
            ) { screen ->
                when (screen) {
                    AppScreen.HOME -> {
                        HomeScreen(
                            viewModel = viewModel,
                            onOpenCategory = { cat ->
                                viewModel.navigateToChat(cat.id)
                            },
                            onOpenReminders = {
                                viewModel.navigateToReminders()
                            },
                            onRequestNotificationPermission = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                } else {
                                    viewModel.showToast("নোটিফিকেশন ইতিমধ্যে চালু রয়েছে")
                                }
                            },
                            onExportBackup = {
                                scope.launch {
                                    try {
                                        viewModel.showToast("ব্যাকআপ ডাউনলোড হচ্ছে")
                                        val jsonString = viewModel.exportBackupJson()
                                        val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                                        val fileName = "deepnote-backup-$dateStr.json"
                                        val file = File(context.cacheDir, fileName)
                                        FileOutputStream(file).use { it.write(jsonString.toByteArray()) }

                                        val uri = FileProvider.getUriForFile(
                                            context,
                                            "${context.packageName}.fileprovider",
                                            file
                                        )

                                        val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                            type = "application/json"
                                            putExtra(Intent.EXTRA_STREAM, uri)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(Intent.createChooser(sendIntent, "ব্যাকআপ ফাইল শেয়ার করুন"))
                                    } catch (e: Exception) {
                                        viewModel.showToast("এক্সপোর্ট করতে ব্যর্থ হয়েছে")
                                    }
                                }
                            },
                            onImportBackup = { uri ->
                                scope.launch {
                                    try {
                                        val jsonString = context.contentResolver.openInputStream(uri)
                                            ?.bufferedReader()?.use { it.readText() }
                                        if (jsonString != null) {
                                            val root = org.json.JSONObject(jsonString)
                                            val catCount = root.optJSONArray("categories")?.length() ?: 0
                                            pendingImportJson = jsonString
                                            pendingImportCategoryCount = catCount
                                            showImportConfirmDialog = true
                                        }
                                    } catch (e: Exception) {
                                        viewModel.showToast("ফাইল পড়তে ব্যর্থ হয়েছে")
                                    }
                                }
                            },
                            onExportAllNotesText = {
                                scope.launch {
                                    try {
                                        val text = viewModel.exportAllNotesAsText()
                                        val file = File(context.cacheDir, "deepnote-all-notes.txt")
                                        FileOutputStream(file).use { it.write(text.toByteArray()) }

                                        val uri = FileProvider.getUriForFile(
                                            context,
                                            "${context.packageName}.fileprovider",
                                            file
                                        )

                                        val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                            type = "text/plain"
                                            putExtra(Intent.EXTRA_STREAM, uri)
                                            putExtra(Intent.EXTRA_TEXT, text)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(Intent.createChooser(sendIntent, "সব নোট শেয়ার করুন"))
                                    } catch (e: Exception) {
                                        viewModel.showToast("এক্সপোর্ট করতে ব্যর্থ হয়েছে")
                                    }
                                }
                            }
                        )
                    }

                    AppScreen.CHAT -> {
                        if (currentCategory != null) {
                            ChatScreen(
                                viewModel = viewModel,
                                category = currentCategory!!,
                                onBack = { viewModel.navigateToHome() }
                            )
                        } else {
                            viewModel.navigateToHome()
                        }
                    }

                    AppScreen.REMINDERS -> {
                        ReminderListScreen(
                            viewModel = viewModel,
                            onBack = { viewModel.navigateToHome() },
                            onOpenCategory = { catId ->
                                viewModel.navigateToChat(catId)
                            }
                        )
                    }
                }
            }

            // Confirm Import Dialog
            if (showImportConfirmDialog && pendingImportJson != null) {
                AlertDialog(
                    onDismissRequest = {
                        showImportConfirmDialog = false
                        pendingImportJson = null
                    },
                    containerColor = DeepNoteTheme.colors.bgSecondary,
                    title = {
                        Text(
                            text = "নিশ্চিত করুন",
                            color = DeepNoteTheme.colors.textPrimary,
                            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                        )
                    },
                    text = {
                        Text(
                            text = "বর্তমান ডেটা মুছে ব্যাকআপের ${pendingImportCategoryCount}টি ক্যাটাগরি লোড হবে",
                            color = DeepNoteTheme.colors.textSecondary,
                            fontSize = 14.sp
                        )
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                scope.launch {
                                    val result = viewModel.importBackupJson(pendingImportJson!!)
                                    if (result.isSuccess) {
                                        viewModel.showToast("ইমপোর্ট সম্পন্ন")
                                    } else {
                                        viewModel.showToast("ইমপোর্ট ব্যর্থ হয়েছে")
                                    }
                                    showImportConfirmDialog = false
                                    pendingImportJson = null
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DeepNoteTheme.colors.danger)
                        ) {
                            Text("হ্যাঁ, লোড করুন", color = Color.White)
                        }
                    },
                    dismissButton = {
                        TextButton(
                            onClick = {
                                showImportConfirmDialog = false
                                pendingImportJson = null
                            }
                        ) {
                            Text("বাতিল", color = DeepNoteTheme.colors.textSecondary)
                        }
                    }
                )
            }
        }
    }
}
