package com.example.ui.chat

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.Note
import com.example.ui.theme.DeepNoteTheme
import java.io.File

@Composable
fun ChatInputBar(
    replyNote: Note?,
    onCancelReply: () -> Unit,
    attachedImagePath: String?,
    onCancelAttachment: () -> Unit,
    onPickImage: (Uri) -> Unit,
    sendMode: String,
    onSendNote: (text: String, forceSide: String?) -> Unit
) {
    var inputText by remember { mutableStateOf("") }
    var showMingleMenu by remember { mutableStateOf(false) }
    val colors = DeepNoteTheme.colors

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            onPickImage(uri)
        }
    }

    val canSend = inputText.isNotBlank() || attachedImagePath != null

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = colors.bgPrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            // Reply Bar (above input)
            if (replyNote != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(colors.bgSecondary)
                        .border(
                            width = 2.dp,
                            color = colors.accent,
                            shape = RoundedCornerShape(topStart = 8.dp, bottomStart = 8.dp)
                        )
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "↩ উত্তর দেওয়া হচ্ছে:",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.accent
                        )
                        Text(
                            text = replyNote.text.ifBlank { "ছবি" },
                            fontSize = 12.5.sp,
                            color = colors.textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    IconButton(
                        onClick = onCancelReply,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_x),
                            contentDescription = "Cancel reply",
                            tint = colors.textMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
            }

            // Attach Bar (above input)
            if (attachedImagePath != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(colors.bgSecondary)
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AsyncImage(
                        model = File(attachedImagePath),
                        contentDescription = "Thumbnail",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(6.dp))
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "ছবি যুক্ত হয়েছে",
                        fontSize = 13.sp,
                        color = colors.accentLight,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = onCancelAttachment,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_x),
                            contentDescription = "Remove photo",
                            tint = colors.textMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
            }

            // Input Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Bottom
            ) {
                // Paperclip icon
                IconButton(
                    onClick = { photoPickerLauncher.launch("image/*") },
                    modifier = Modifier
                        .size(42.dp)
                        .testTag("attach_button")
                ) {
                    Icon(
                        painter = painterResource(R.drawable.ic_lucide_paperclip),
                        contentDescription = "Attach",
                        tint = colors.textSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                // Expanding text input (up to 110dp)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(20.dp))
                        .background(colors.bgSecondary)
                        .heightIn(min = 42.dp, max = 110.dp)
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    if (inputText.isEmpty()) {
                        Text(
                            text = "নতুন নোট লিখুন...",
                            fontSize = 14.5.sp,
                            color = colors.textMuted
                        )
                    }
                    BasicTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        textStyle = TextStyle(
                            color = colors.textPrimary,
                            fontSize = 14.5.sp,
                            lineHeight = 20.sp
                        ),
                        cursorBrush = SolidColor(colors.accent),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("chat_text_input")
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Send Icon Button
                Box {
                    IconButton(
                        onClick = {
                            if (canSend) {
                                if (sendMode == "mingle") {
                                    showMingleMenu = true
                                } else {
                                    onSendNote(inputText, null)
                                    inputText = ""
                                }
                            }
                        },
                        enabled = canSend,
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(if (canSend) colors.accent else Color.Transparent)
                            .testTag("send_note_button")
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_send),
                            contentDescription = "Send",
                            tint = if (canSend) Color.White else colors.textMuted,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Mingle Mode Side Picker Dropdown
                    DropdownMenu(
                        expanded = showMingleMenu,
                        onDismissRequest = { showMingleMenu = false },
                        modifier = Modifier.background(colors.bgSecondary)
                    ) {
                        DropdownMenuItem(
                            text = { Text("ডান পাশে পাঠান (Right)", color = colors.textPrimary) },
                            leadingIcon = {
                                Icon(
                                    painter = painterResource(R.drawable.ic_lucide_arrow_right),
                                    contentDescription = null,
                                    tint = colors.accent
                                )
                            },
                            onClick = {
                                showMingleMenu = false
                                onSendNote(inputText, "right")
                                inputText = ""
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("বাম পাশে পাঠান (Left)", color = colors.textPrimary) },
                            leadingIcon = {
                                Icon(
                                    painter = painterResource(R.drawable.ic_lucide_arrow_left),
                                    contentDescription = null,
                                    tint = colors.textSecondary
                                )
                            },
                            onClick = {
                                showMingleMenu = false
                                onSendNote(inputText, "left")
                                inputText = ""
                            }
                        )
                    }
                }
            }
        }
    }
}
