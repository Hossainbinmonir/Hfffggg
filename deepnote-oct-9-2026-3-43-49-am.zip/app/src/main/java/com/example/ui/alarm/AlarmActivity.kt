package com.example.ui.alarm

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MainActivity
import com.example.R
import com.example.alarm.AlarmScheduler
import com.example.alarm.NotificationHelper
import com.example.audio.SoundPlayer
import com.example.data.local.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AlarmActivity : ComponentActivity() {

    companion object {
        const val EXTRA_REMINDER_ID = "alarm_reminder_id"
        const val EXTRA_HEAD = "alarm_head"
        const val EXTRA_SUB = "alarm_sub"
        const val EXTRA_SOUND = "alarm_sound"
        const val EXTRA_WHEN = "alarm_when"
        const val EXTRA_CAT_ID = "alarm_cat_id"
        const val EXTRA_NOTE_ID = "alarm_note_id"
    }

    private var reminderId: String = ""
    private var head: String = ""
    private var sub: String = ""
    private var sound: String = "bell"
    private var whenTime: Long = 0L
    private var catId: String? = null
    private var noteId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val km = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
            km?.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }

        reminderId = intent.getStringExtra(EXTRA_REMINDER_ID) ?: ""
        head = intent.getStringExtra(EXTRA_HEAD) ?: "রিমাইন্ডার"
        sub = intent.getStringExtra(EXTRA_SUB) ?: ""
        sound = intent.getStringExtra(EXTRA_SOUND) ?: "bell"
        whenTime = intent.getLongExtra(EXTRA_WHEN, System.currentTimeMillis())
        catId = intent.getStringExtra(EXTRA_CAT_ID)
        noteId = intent.getStringExtra(EXTRA_NOTE_ID)

        // Start looping alarm sound and vibration
        SoundPlayer.startAlarmLoop(this, sound)

        setContent {
            AlarmScreen(
                head = head,
                sub = sub,
                whenTime = whenTime,
                catId = catId,
                onDismiss = { dismissAlarm() },
                onSnooze = { minutes -> snoozeAlarm(minutes) },
                onOpenNote = { openLinkedNote() }
            )
        }
    }

    private fun dismissAlarm() {
        SoundPlayer.stopAlarmLoop()
        NotificationHelper.cancelNotification(this, reminderId)
        val db = AppDatabase.getInstance(this)
        CoroutineScope(Dispatchers.IO).launch {
            db.reminderDao().updateDone(reminderId, true)
            db.reminderDao().updateFired(reminderId, true)
        }
        finish()
    }

    private fun snoozeAlarm(minutes: Int) {
        SoundPlayer.stopAlarmLoop()
        NotificationHelper.cancelNotification(this, reminderId)
        val db = AppDatabase.getInstance(this)
        CoroutineScope(Dispatchers.IO).launch {
            val newTime = System.currentTimeMillis() + (minutes * 60 * 1000L)
            db.reminderDao().snooze(reminderId, newTime)
            val updated = db.reminderDao().getReminderById(reminderId)
            if (updated != null) {
                AlarmScheduler.scheduleReminder(this@AlarmActivity, updated)
            }
        }
        finish()
    }

    private fun openLinkedNote() {
        SoundPlayer.stopAlarmLoop()
        NotificationHelper.cancelNotification(this, reminderId)
        val db = AppDatabase.getInstance(this)
        CoroutineScope(Dispatchers.IO).launch {
            db.reminderDao().updateDone(reminderId, true)
        }
        val mainIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("OPEN_CATEGORY_ID", catId)
        }
        startActivity(mainIntent)
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        SoundPlayer.stopAlarmLoop()
    }
}

@Composable
fun AlarmScreen(
    head: String,
    sub: String,
    whenTime: Long,
    catId: String?,
    onDismiss: () -> Unit,
    onSnooze: (Int) -> Unit,
    onOpenNote: () -> Unit
) {
    // Ringing bell animation
    val infiniteTransition = rememberInfiniteTransition(label = "bell_ring")
    val rotation by infiniteTransition.animateFloat(
        initialValue = -22f,
        targetValue = 22f,
        animationSpec = infiniteRepeatable(
            animation = tween(180, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "rotation"
    )

    val timeFormatted = rememberFormattedTime(whenTime)

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xEE090B0E)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("alarm_card"),
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF181B20)
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // 80dp circular animated bell icon
                    Box(
                        modifier = Modifier
                            .size(88.dp)
                            .background(
                                brush = Brush.radialGradient(
                                    listOf(Color(0xFFFA3E3E), Color(0xFF8B0000))
                                ),
                                shape = CircleShape
                            )
                            .border(2.dp, Color(0xFFFF6B6B), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_bell_ringing),
                            contentDescription = "অ্যালার্ম বাজছে",
                            tint = Color.White,
                            modifier = Modifier
                                .size(44.dp)
                                .rotate(rotation)
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        text = head,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )

                    if (sub.isNotBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = sub,
                            fontSize = 15.sp,
                            color = Color(0xFFA9B0BA),
                            textAlign = TextAlign.Center
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_clock),
                            contentDescription = null,
                            tint = Color(0xFF00C6FF),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = timeFormatted,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF00C6FF)
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Snooze chips
                    Text(
                        text = "স্নুজ করুন:",
                        fontSize = 13.sp,
                        color = Color(0xFF6B7480)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = false,
                            onClick = { onSnooze(5) },
                            label = { Text("৫ মিনিট", fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = Color(0xFF20242A),
                                labelColor = Color.White
                            )
                        )
                        FilterChip(
                            selected = false,
                            onClick = { onSnooze(10) },
                            label = { Text("১০ মিনিট", fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = Color(0xFF20242A),
                                labelColor = Color.White
                            )
                        )
                        FilterChip(
                            selected = false,
                            onClick = { onSnooze(30) },
                            label = { Text("৩০ মিনিট", fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = Color(0xFF20242A),
                                labelColor = Color.White
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(28.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = onDismiss,
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("dismiss_alarm_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFFA3E3E)
                            )
                        ) {
                            Text("বন্ধ করুন", fontWeight = FontWeight.Bold, color = Color.White)
                        }

                        if (!catId.isNullOrBlank()) {
                            OutlinedButton(
                                onClick = onOpenNote,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(50.dp)
                                    .testTag("open_linked_note_button"),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = Color(0xFF00C6FF)
                                )
                            ) {
                                Text("নোট খুলুন", fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun rememberFormattedTime(timeMs: Long): String {
    val sdf = SimpleDateFormat("hh:mm a, dd MMM", Locale("bn"))
    return sdf.format(Date(timeMs))
}
