package com.example.ui.home

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Category
import com.example.data.model.Note
import com.example.ui.components.CategoryAvatar
import com.example.ui.theme.DeepNoteTheme
import kotlin.math.roundToInt

@Composable
fun CategoryItem(
    category: Category,
    lastNote: Note?,
    noteCount: Int,
    isReorderMode: Boolean,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val colors = DeepNoteTheme.colors
    val density = LocalDensity.current
    val maxRevealPx = with(density) { 120.dp.toPx() }

    var offsetX by remember { mutableFloatStateOf(0f) }
    val animatedOffset by animateFloatAsState(targetValue = offsetX, label = "swipe_offset")

    val previewText = remember(lastNote) {
        when {
            lastNote == null -> "কোন নোট নেই"
            !lastNote.image.isNullOrBlank() -> "ছবি"
            lastNote.text.isNotBlank() -> lastNote.text.replace("\n", " ")
            else -> "কোন নোট নেই"
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(78.dp)
            .background(colors.bgPrimary)
    ) {
        // Revealed Actions Behind
        Row(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .width(120.dp)
                .fillMaxHeight(),
            horizontalArrangement = Arrangement.End
        ) {
            // Edit Button (Accent)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(colors.accent)
                    .clickable {
                        offsetX = 0f
                        onEdit()
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painter = painterResource(R.drawable.ic_lucide_pencil),
                    contentDescription = "সম্পাদনা",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }

            // Delete Button (Red)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(colors.danger)
                    .clickable {
                        offsetX = 0f
                        onDelete()
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painter = painterResource(R.drawable.ic_lucide_trash_2),
                    contentDescription = "মুছুন",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        // Foreground Content
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight()
                .offset { IntOffset(animatedOffset.roundToInt(), 0) }
                .draggable(
                    orientation = Orientation.Horizontal,
                    state = rememberDraggableState { delta ->
                        val newOffset = offsetX + delta
                        offsetX = newOffset.coerceIn(-maxRevealPx, 0f)
                    },
                    onDragStopped = {
                        val threshold = -maxRevealPx / 2
                        offsetX = if (offsetX < threshold) -maxRevealPx else 0f
                    }
                )
                .clickable {
                    if (offsetX < -10f) {
                        offsetX = 0f
                    } else {
                        onClick()
                    }
                }
                .testTag("category_row_${category.id}"),
            color = colors.bgPrimary
        ) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (isReorderMode) {
                        Column(
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(end = 10.dp)
                        ) {
                            IconButton(
                                onClick = onMoveUp,
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.ic_lucide_move),
                                    contentDescription = "Move Up",
                                    tint = colors.textSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    // 50dp circular avatar
                    CategoryAvatar(category = category, size = 50.dp)

                    Spacer(modifier = Modifier.width(14.dp))

                    // Title & Preview
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (category.pin) {
                                Icon(
                                    painter = painterResource(R.drawable.ic_lucide_star),
                                    contentDescription = "Pinned",
                                    tint = colors.accent,
                                    modifier = Modifier
                                        .size(15.dp)
                                        .padding(end = 4.dp)
                                )
                            }
                            Text(
                                text = category.name,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = colors.textPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Spacer(modifier = Modifier.height(3.dp))

                        Text(
                            text = previewText,
                            fontSize = 13.5.sp,
                            color = colors.textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Note count badge
                    if (noteCount > 0) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(colors.bgTertiary)
                                .padding(horizontal = 9.dp, vertical = 3.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$noteCount",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = colors.textSecondary
                            )
                        }
                    }
                }

                HorizontalDivider(
                    thickness = 1.dp,
                    color = colors.border.copy(alpha = 0.5f)
                )
            }
        }
    }
}
