package com.example.ui.chat

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.Category
import com.example.data.model.Note
import com.example.ui.components.CategoryAvatar
import com.example.ui.components.NoteRichContent
import com.example.ui.theme.DeepNoteTheme
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatBubble(
    note: Note,
    category: Category,
    replyNote: Note?,
    showAvatars: Boolean,
    fontSizeIndex: Int,
    isSelected: Boolean,
    onToggleSelect: () -> Unit,
    onReply: () -> Unit,
    onStar: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onReminder: () -> Unit,
    onToggleCheckbox: (String) -> Unit,
    onJumpToNote: (String) -> Unit
) {
    val colors = DeepNoteTheme.colors
    val clipboardManager = LocalClipboardManager.current
    var showContextMenu by remember { mutableStateOf(false) }

    val isRight = note.side == "right"
    val fontSize = when (fontSizeIndex) {
        0 -> 13.sp
        2 -> 17.sp
        else -> 15.sp
    }

    val bubbleShape = if (isRight) {
        RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 18.dp, bottomEnd = 3.dp)
    } else {
        RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 3.dp, bottomEnd = 18.dp)
    }

    val bubbleBg = if (isRight) {
        if (!category.themeMine.isNullOrBlank()) {
            try {
                Color(android.graphics.Color.parseColor(category.themeMine))
            } catch (_: Exception) {
                colors.accent
            }
        } else {
            colors.accent
        }
    } else {
        if (!category.themeOther.isNullOrBlank()) {
            try {
                Color(android.graphics.Color.parseColor(category.themeOther))
            } catch (_: Exception) {
                colors.bgTertiary
            }
        } else {
            colors.bgTertiary
        }
    }

    val textColor = if (isRight) Color.White else colors.textPrimary

    val formattedTime = remember(note.timestamp) {
        val sdf = SimpleDateFormat("hh:mm a", Locale("bn"))
        sdf.format(Date(note.timestamp))
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 4.dp),
        horizontalArrangement = if (isRight) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Bottom
    ) {
        // Left Avatar (if enabled and left side)
        if (!isRight && showAvatars) {
            CategoryAvatar(category = category, size = 28.dp)
            Spacer(modifier = Modifier.width(6.dp))
        }

        Box(
            modifier = Modifier
                .widthIn(max = 285.dp)
                .clip(bubbleShape)
                .background(bubbleBg)
                .border(
                    width = if (isSelected) 2.dp else 0.dp,
                    color = if (isSelected) colors.accentLight else Color.Transparent,
                    shape = bubbleShape
                )
                .combinedClickable(
                    onClick = {
                        if (isSelected) {
                            onToggleSelect()
                        }
                    },
                    onLongClick = {
                        showContextMenu = true
                    }
                )
                .padding(10.dp)
                .testTag("note_bubble_${note.id}")
        ) {
            Column {
                // Reply Quote box at top of bubble
                if (replyNote != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color.Black.copy(alpha = 0.2f))
                            .border(
                                width = 2.dp,
                                color = colors.accentLight,
                                shape = RoundedCornerShape(topStart = 6.dp, bottomStart = 6.dp)
                            )
                            .combinedClickable(onClick = { onJumpToNote(replyNote.id) })
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Column {
                            Text(
                                text = "↩ উত্তর",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.accentLight
                            )
                            Text(
                                text = replyNote.text.ifBlank { "ছবি" },
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }

                // Note Image (if present)
                if (!note.image.isNullOrBlank()) {
                    AsyncImage(
                        model = File(note.image),
                        contentDescription = "ছবি",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 260.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                }

                // Rich Text
                if (note.text.isNotBlank()) {
                    NoteRichContent(
                        text = note.text,
                        fontSize = fontSize,
                        textColor = textColor,
                        onToggleCheckbox = onToggleCheckbox
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Time & Star at bottom-right of bubble
                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (note.star) {
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_star),
                            contentDescription = "Starred",
                            tint = Color(0xFFFFD700),
                            modifier = Modifier
                                .size(12.dp)
                                .padding(end = 2.dp)
                        )
                    }

                    Text(
                        text = formattedTime,
                        fontSize = 10.sp,
                        color = textColor.copy(alpha = 0.65f)
                    )
                }
            }

            // Context Menu Dropdown
            DropdownMenu(
                expanded = showContextMenu,
                onDismissRequest = { showContextMenu = false },
                modifier = Modifier.background(colors.bgSecondary)
            ) {
                DropdownMenuItem(
                    text = { Text("কপি", color = colors.textPrimary) },
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_copy),
                            contentDescription = null,
                            tint = colors.textSecondary
                        )
                    },
                    onClick = {
                        showContextMenu = false
                        clipboardManager.setText(AnnotatedString(note.text))
                    }
                )

                DropdownMenuItem(
                    text = { Text("উত্তর দিন (Reply)", color = colors.textPrimary) },
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_corner_up_left),
                            contentDescription = null,
                            tint = colors.textSecondary
                        )
                    },
                    onClick = {
                        showContextMenu = false
                        onReply()
                    }
                )

                DropdownMenuItem(
                    text = { Text(if (note.star) "স্টার সরান" else "স্টার দিন", color = colors.textPrimary) },
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_star),
                            contentDescription = null,
                            tint = if (note.star) Color(0xFFFFD700) else colors.textSecondary
                        )
                    },
                    onClick = {
                        showContextMenu = false
                        onStar()
                    }
                )

                DropdownMenuItem(
                    text = { Text("রিমাইন্ডার তৈরি", color = colors.textPrimary) },
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_bell),
                            contentDescription = null,
                            tint = colors.textSecondary
                        )
                    },
                    onClick = {
                        showContextMenu = false
                        onReminder()
                    }
                )

                DropdownMenuItem(
                    text = { Text("সম্পাদনা", color = colors.textPrimary) },
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_pencil),
                            contentDescription = null,
                            tint = colors.textSecondary
                        )
                    },
                    onClick = {
                        showContextMenu = false
                        onEdit()
                    }
                )

                DropdownMenuItem(
                    text = { Text("নির্বাচন (Select)", color = colors.textPrimary) },
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_check_square),
                            contentDescription = null,
                            tint = colors.textSecondary
                        )
                    },
                    onClick = {
                        showContextMenu = false
                        onToggleSelect()
                    }
                )

                DropdownMenuItem(
                    text = { Text("মুছুন", color = colors.danger) },
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_trash_2),
                            contentDescription = null,
                            tint = colors.danger
                        )
                    },
                    onClick = {
                        showContextMenu = false
                        onDelete()
                    }
                )
            }
        }
    }
}
