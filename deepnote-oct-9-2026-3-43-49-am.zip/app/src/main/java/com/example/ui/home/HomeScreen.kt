package com.example.ui.home

import android.net.Uri
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Category
import com.example.data.model.Note
import com.example.ui.MainViewModel
import com.example.ui.SearchFilter
import com.example.ui.lock.SetPinDialog
import com.example.ui.theme.DeepNoteTheme

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onOpenCategory: (Category) -> Unit,
    onOpenReminders: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onExportBackup: () -> Unit,
    onImportBackup: (Uri) -> Unit,
    onExportAllNotesText: () -> Unit
) {
    val colors = DeepNoteTheme.colors

    val appTitle by viewModel.appTitle.collectAsState()
    val appTheme by viewModel.appTheme.collectAsState()
    val accentIndex by viewModel.accentIndex.collectAsState()
    val fontSize by viewModel.fontSize.collectAsState()
    val remind7dBackup by viewModel.remindBackup.collectAsState()
    val userPin by viewModel.userPin.collectAsState()

    val categories by viewModel.categories.collectAsState()
    val allNotes by viewModel.allNotes.collectAsState()
    val isArchivedView by viewModel.showArchived.collectAsState()
    val isReorderMode by viewModel.isReorderMode.collectAsState()

    val upcomingRemindersCount by viewModel.upcomingReminderCount.collectAsState()
    val firedOrDueCount by viewModel.firedOrDueCount.collectAsState()

    val searchQuery by viewModel.searchQuery.collectAsState()
    val searchFilter by viewModel.searchFilter.collectAsState()
    val isSearchFocused by viewModel.isSearchFocused.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()

    // Dialog states
    var showNewCategoryDialog by remember { mutableStateOf(false) }
    var categoryToEdit by remember { mutableStateOf<Category?>(null) }
    var showEditTitleDialog by remember { mutableStateOf(false) }
    var showMenuBottomSheet by remember { mutableStateOf(false) }
    var showSetPinDialog by remember { mutableStateOf(false) }

    // Floating action button pulsing animation
    val infiniteTransition = rememberInfiniteTransition(label = "fab_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "fab_scale"
    )

    // Precalculate note preview and counts
    val notesByCategory = remember(allNotes) {
        allNotes.groupBy { it.categoryId }
    }

    Scaffold(
        containerColor = colors.bgPrimary,
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    categoryToEdit = null
                    showNewCategoryDialog = true
                },
                shape = CircleShape,
                containerColor = Color.Transparent,
                elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 8.dp),
                modifier = Modifier
                    .padding(end = 6.dp, bottom = 6.dp)
                    .size(56.dp)
                    .scale(pulseScale)
                    .testTag("add_category_fab")
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(
                            brush = Brush.linearGradient(
                                listOf(colors.accent, colors.accentLight)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painter = painterResource(R.drawable.ic_lucide_plus),
                        contentDescription = "নতুন ক্যাটাগরি",
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // 1. HEADER ROW (padding 20dp horizontal, 22dp top, 10dp bottom)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // App Title Text
                Text(
                    text = if (isArchivedView) "আর্কাইভ" else appTitle,
                    fontSize = 30.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = colors.textPrimary,
                    letterSpacing = (-0.02).sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { showEditTitleDialog = true }
                        .testTag("app_title_header")
                )

                // 4 Icon Buttons in a row (spacing 2dp, each 40dp circle)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Bell icon with badge
                    Box(
                        modifier = Modifier.size(40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        IconButton(
                            onClick = onOpenReminders,
                            modifier = Modifier
                                .size(40.dp)
                                .testTag("reminders_bell_button")
                        ) {
                            Icon(
                                painter = painterResource(
                                    if (firedOrDueCount > 0) R.drawable.ic_lucide_bell_ringing
                                    else R.drawable.ic_lucide_bell
                                ),
                                contentDescription = "রিমাইন্ডার",
                                tint = if (firedOrDueCount > 0) colors.danger else colors.textSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Badge on bell
                        if (upcomingRemindersCount > 0 || firedOrDueCount > 0) {
                            val count = upcomingRemindersCount + firedOrDueCount
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(top = 4.dp, end = 4.dp)
                                    .size(17.dp)
                                    .clip(CircleShape)
                                    .background(colors.danger),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (count > 9) "9+" else "$count",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }

                    // Hamburger Menu
                    IconButton(
                        onClick = { showMenuBottomSheet = true },
                        modifier = Modifier
                            .size(40.dp)
                            .testTag("hamburger_menu_button")
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_menu),
                            contentDescription = "মেনু",
                            tint = colors.textSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Edit (Pencil)
                    IconButton(
                        onClick = { showEditTitleDialog = true },
                        modifier = Modifier
                            .size(40.dp)
                            .testTag("edit_title_button")
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_pencil),
                            contentDescription = "শিরোনাম ও থিম",
                            tint = colors.textSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Theme toggle (Moon/Sun)
                    IconButton(
                        onClick = { viewModel.toggleTheme() },
                        modifier = Modifier
                            .size(40.dp)
                            .testTag("theme_toggle_button")
                    ) {
                        Icon(
                            painter = painterResource(
                                if (appTheme == "dark") R.drawable.ic_lucide_sun else R.drawable.ic_lucide_moon
                            ),
                            contentDescription = "থিম পরিবর্তন",
                            tint = colors.textSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // 2. SEARCH BAR with filter chips
            SearchBarWithResults(
                query = searchQuery,
                onQueryChange = { viewModel.setSearchQuery(it) },
                activeFilter = searchFilter,
                onFilterChange = { viewModel.setSearchFilter(it) },
                isFocused = isSearchFocused,
                onFocusChange = { viewModel.setSearchFocused(it) },
                results = searchResults,
                categories = categories,
                onSelectNote = { note ->
                    val cat = categories.firstOrNull { it.id == note.categoryId }
                    if (cat != null) {
                        onOpenCategory(cat)
                    }
                }
            )

            // 3. CATEGORY LIST
            if (categories.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_folder),
                            contentDescription = null,
                            tint = colors.textMuted,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (isArchivedView) "কোন আর্কাইভ ক্যাটাগরি নেই"
                            else "কোন ক্যাটাগরি নেই। নিচে + আইকনে ক্লিক করুন।",
                            fontSize = 14.5.sp,
                            color = colors.textMuted,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    itemsIndexed(
                        items = categories,
                        key = { _, cat -> cat.id }
                    ) { index, cat ->
                        val catNotes = notesByCategory[cat.id] ?: emptyList()
                        val lastNote = catNotes.lastOrNull()
                        val count = catNotes.size

                        CategoryItem(
                            category = cat,
                            lastNote = lastNote,
                            noteCount = count,
                            isReorderMode = isReorderMode,
                            onMoveUp = {
                                if (index > 0) {
                                    val prev = categories[index - 1]
                                    viewModel.reorderCategory(cat.id, index - 1)
                                    viewModel.reorderCategory(prev.id, index)
                                }
                            },
                            onMoveDown = {
                                if (index < categories.size - 1) {
                                    val next = categories[index + 1]
                                    viewModel.reorderCategory(cat.id, index + 1)
                                    viewModel.reorderCategory(next.id, index)
                                }
                            },
                            onClick = { onOpenCategory(cat) },
                            onEdit = {
                                categoryToEdit = cat
                                showNewCategoryDialog = true
                            },
                            onDelete = {
                                viewModel.deleteCategory(cat)
                            }
                        )
                    }
                }
            }
        }

        // Dialogs
        if (showNewCategoryDialog) {
            NewCategoryDialog(
                categoryToEdit = categoryToEdit,
                onDismiss = { showNewCategoryDialog = false },
                onSave = { name, icon, img, color ->
                    if (categoryToEdit == null) {
                        viewModel.createCategory(name, icon, img, color)
                    } else {
                        viewModel.updateCategory(
                            categoryToEdit!!.copy(
                                name = name,
                                icon = icon,
                                img = img,
                                color = color
                            )
                        )
                    }
                },
                onPickImage = { uri ->
                    viewModel.saveImageFromUri(uri)
                }
            )
        }

        if (showEditTitleDialog) {
            EditTitleDialog(
                currentTitle = appTitle,
                currentAccentIndex = accentIndex,
                onDismiss = { showEditTitleDialog = false },
                onSave = { newTitle, newAccent ->
                    viewModel.updateTitleAndAccent(newTitle, newAccent)
                }
            )
        }

        if (showMenuBottomSheet) {
            val storage = viewModel.getStorageUsage()
            MenuBottomSheet(
                onDismiss = { showMenuBottomSheet = false },
                pendingReminderCount = upcomingRemindersCount + firedOrDueCount,
                isArchivedView = isArchivedView,
                onToggleArchivedView = { viewModel.toggleArchivedView() },
                isReorderMode = isReorderMode,
                onToggleReorderMode = { viewModel.toggleReorderMode() },
                fontSize = fontSize,
                onFontSizeChange = { viewModel.setFontSize(it) },
                hasPin = userPin != null,
                onOpenPinSetup = { showSetPinDialog = true },
                remind7dBackup = remind7dBackup,
                onToggle7dBackup = {
                    // Update preference
                },
                storageUsage = storage,
                onOpenAllReminders = onOpenReminders,
                onNewReminder = {
                    // Will open new reminder dialog
                    onOpenReminders()
                },
                onRequestNotificationPermission = onRequestNotificationPermission,
                onExportBackup = onExportBackup,
                onImportBackupFile = onImportBackup,
                onExportAllNotesText = onExportAllNotesText
            )
        }

        if (showSetPinDialog) {
            SetPinDialog(
                currentPin = userPin,
                onDismiss = { showSetPinDialog = false },
                onSavePin = { pin: String? ->
                    viewModel.setPin(pin)
                }
            )
        }
    }
}
