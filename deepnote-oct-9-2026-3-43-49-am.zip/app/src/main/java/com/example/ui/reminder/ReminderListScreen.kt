package com.example.ui.reminder

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Category
import com.example.data.model.Reminder
import com.example.ui.MainViewModel
import com.example.ui.theme.DeepNoteTheme
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun ReminderListScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onOpenCategory: (String) -> Unit
) {
    val colors = DeepNoteTheme.colors

    BackHandler {
        onBack()
    }

    val reminders by viewModel.allReminders.collectAsState()
    val allCategories by viewModel.allCategoriesList.collectAsState()

    var showCreateDialog by remember { mutableStateOf(false) }
    var selectedReminderForSheet by remember { mutableStateOf<Reminder?>(null) }

    Scaffold(
        containerColor = colors.bgPrimary,
        topBar = {
            Surface(color = colors.bgSecondary, shadowElevation = 2.dp) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(40.dp)
                            .testTag("reminder_back_button")
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_chevron_left),
                            contentDescription = "Back",
                            tint = colors.textPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    Text(
                        text = "রিমাইন্ডার",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary,
                        modifier = Modifier.weight(1f)
                    )

                    IconButton(
                        onClick = { showCreateDialog = true },
                        modifier = Modifier
                            .size(40.dp)
                            .testTag("add_reminder_button")
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_plus),
                            contentDescription = "New Reminder",
                            tint = colors.accent,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        if (reminders.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        painter = painterResource(R.drawable.ic_lucide_bell),
                        contentDescription = null,
                        tint = colors.textMuted,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "কোন রিমাইন্ডার নেই। উপরে + চেপে তৈরি করুন।",
                        fontSize = 14.5.sp,
                        color = colors.textMuted,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            // Group reminders by section:
            // সম্পন্ন | মিস হয়েছে | আগের | আজ | আগামীকাল | এই সপ্তাহে | পরে
            val now = System.currentTimeMillis()
            val cal = Calendar.getInstance()
            val currentDay = cal.get(Calendar.DAY_OF_YEAR)
            val currentYear = cal.get(Calendar.YEAR)

            val groupedReminders = remember(reminders) {
                val map = linkedMapOf<String, MutableList<Reminder>>()
                val sections = listOf(
                    "মিস হয়েছে",
                    "আজ",
                    "আগামীকাল",
                    "এই সপ্তাহে",
                    "পরে",
                    "সম্পন্ন"
                )
                sections.forEach { map[it] = mutableListOf() }

                reminders.forEach { r ->
                    if (r.done) {
                        map["সম্পন্ন"]?.add(r)
                    } else if (r.fired || r.whenTime < now) {
                        map["মিস হয়েছে"]?.add(r)
                    } else {
                        val rCal = Calendar.getInstance().apply { timeInMillis = r.whenTime }
                        val rDay = rCal.get(Calendar.DAY_OF_YEAR)
                        val rYear = rCal.get(Calendar.YEAR)

                        if (rYear == currentYear && rDay == currentDay) {
                            map["আজ"]?.add(r)
                        } else if (rYear == currentYear && rDay == currentDay + 1) {
                            map["আগামীকাল"]?.add(r)
                        } else if (r.whenTime - now <= 7 * 24 * 60 * 60 * 1000L) {
                            map["এই সপ্তাহে"]?.add(r)
                        } else {
                            map["পরে"]?.add(r)
                        }
                    }
                }
                map.filter { it.value.isNotEmpty() }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                groupedReminders.forEach { (section, items) ->
                    item(key = "section_$section") {
                        Text(
                            text = section,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (section == "মিস হয়েছে") colors.danger else colors.accentLight,
                            modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 6.dp)
                        )
                    }

                    items(items, key = { it.id }) { reminder ->
                        ReminderRow(
                            reminder = reminder,
                            onClick = { selectedReminderForSheet = reminder }
                        )
                        HorizontalDivider(
                            modifier = Modifier.padding(horizontal = 20.dp),
                            color = colors.border.copy(alpha = 0.4f),
                            thickness = 1.dp
                        )
                    }
                }
            }
        }

        // Create Dialog
        if (showCreateDialog) {
            NewReminderDialog(
                categories = allCategories,
                onDismiss = { showCreateDialog = false },
                onSave = { head, sub, whenTime, sound, catId, noteId ->
                    viewModel.createReminder(head, sub, whenTime, sound, catId, noteId)
                },
                onPreviewSound = { sound ->
                    viewModel.previewSound(sound)
                }
            )
        }

        // Action Sheet
        selectedReminderForSheet?.let { reminder ->
            ReminderActionSheet(
                reminder = reminder,
                onDismiss = { selectedReminderForSheet = null },
                onOpenLinkedNote = {
                    if (!reminder.catId.isNullOrBlank()) {
                        onOpenCategory(reminder.catId)
                    }
                },
                onToggleDone = {
                    viewModel.toggleReminderDone(reminder)
                },
                onTriggerAgain = {
                    viewModel.createReminder(
                        reminder.head,
                        reminder.sub,
                        System.currentTimeMillis() + 60 * 1000L,
                        reminder.sound,
                        reminder.catId,
                        reminder.noteId
                    )
                },
                onDelete = {
                    viewModel.deleteReminder(reminder)
                }
            )
        }
    }
}

@Composable
fun ReminderRow(
    reminder: Reminder,
    onClick: () -> Unit
) {
    val colors = DeepNoteTheme.colors
    val isDue = !reminder.done && (reminder.fired || reminder.whenTime <= System.currentTimeMillis())
    val isDone = reminder.done

    val rowBackground = if (isDue) colors.danger.copy(alpha = 0.12f) else Color.Transparent
    val rowAlpha = if (isDone) 0.55f else 1.0f

    val formattedTime = remember(reminder.whenTime) {
        val now = System.currentTimeMillis()
        val diff = reminder.whenTime - now
        val timeFormat = SimpleDateFormat("HH:mm", Locale("bn"))
        val dateFormat = SimpleDateFormat("dd MMM, HH:mm", Locale("bn"))

        when {
            diff in 0..(5 * 60 * 1000L) -> "৫ মিনিট পর"
            diff in (5 * 60 * 1000L)..(30 * 60 * 1000L) -> "৩০ মিনিট পর"
            else -> {
                val calNow = Calendar.getInstance()
                val calTarget = Calendar.getInstance().apply { timeInMillis = reminder.whenTime }
                if (calNow.get(Calendar.DAY_OF_YEAR) == calTarget.get(Calendar.DAY_OF_YEAR) &&
                    calNow.get(Calendar.YEAR) == calTarget.get(Calendar.YEAR)
                ) {
                    "আজ ${timeFormat.format(Date(reminder.whenTime))}"
                } else if (calNow.get(Calendar.DAY_OF_YEAR) + 1 == calTarget.get(Calendar.DAY_OF_YEAR) &&
                    calNow.get(Calendar.YEAR) == calTarget.get(Calendar.YEAR)
                ) {
                    "আগামীকাল ${timeFormat.format(Date(reminder.whenTime))}"
                } else {
                    dateFormat.format(Date(reminder.whenTime))
                }
            }
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(rowBackground)
            .alpha(rowAlpha)
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // 42dp icon box, rounded 12dp
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(
                    when {
                        isDone -> Color(0xFF2E9E6B).copy(alpha = 0.2f)
                        isDue -> colors.danger.copy(alpha = 0.2f)
                        else -> colors.accent.copy(alpha = 0.15f)
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                painter = painterResource(
                    when {
                        isDone -> R.drawable.ic_lucide_check
                        isDue -> R.drawable.ic_lucide_alarm_clock
                        else -> R.drawable.ic_lucide_bell
                    }
                ),
                contentDescription = null,
                tint = when {
                    isDone -> Color(0xFF2E9E6B)
                    isDue -> colors.danger
                    else -> colors.accent
                },
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(14.dp))

        // Title + Subtitle
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = reminder.head,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            if (reminder.sub.isNotBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = reminder.sub,
                    fontSize = 13.sp,
                    color = colors.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Spacer(modifier = Modifier.width(10.dp))

        // Right side: clock icon + formatted time
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                painter = painterResource(R.drawable.ic_lucide_clock),
                contentDescription = null,
                tint = if (isDue) colors.danger else colors.textMuted,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = formattedTime,
                fontSize = 12.5.sp,
                color = if (isDue) colors.danger else colors.textSecondary,
                fontWeight = if (isDue) FontWeight.SemiBold else FontWeight.Normal
            )
        }
    }
}
