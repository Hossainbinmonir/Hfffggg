package com.example.ui.chat

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Category
import com.example.data.model.Note
import com.example.ui.MainViewModel
import com.example.ui.components.CategoryAvatar
import com.example.ui.reminder.NewReminderDialog
import com.example.ui.theme.DeepNoteTheme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatScreen(
    viewModel: MainViewModel,
    category: Category,
    onBack: () -> Unit
) {
    val colors = DeepNoteTheme.colors
    val context = LocalContext.current

    BackHandler {
        onBack()
    }

    val notes by viewModel.currentNotes.collectAsState()
    val allCategories by viewModel.allCategoriesList.collectAsState()
    val sendMode by viewModel.sendMode.collectAsState()
    val showAvatars by viewModel.showAvatars.collectAsState()
    val fontSizeIndex by viewModel.fontSize.collectAsState()
    val selectedNoteIds by viewModel.selectedNoteIds.collectAsState()
    val replyNote by viewModel.replyNote.collectAsState()
    val attachedImagePath by viewModel.attachedImagePath.collectAsState()

    var showSettingsMenu by remember { mutableStateOf(false) }
    var showChatThemeDialog by remember { mutableStateOf(false) }
    var showNewReminderDialog by remember { mutableStateOf(false) }
    var reminderPreFillNote by remember { mutableStateOf<Note?>(null) }
    var noteToEdit by remember { mutableStateOf<Note?>(null) }
    var showMoveDialog by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()

    // Scroll to bottom on new notes
    LaunchedEffect(notes.size) {
        if (notes.isNotEmpty()) {
            listState.animateScrollToItem(notes.size - 1)
        }
    }

    val noteMap = remember(notes) { notes.associateBy { it.id } }

    Scaffold(
        containerColor = colors.bgPrimary,
        topBar = {
            Column {
                // Header (row, 8dp padding, gap 8dp)
                Surface(
                    color = colors.bgSecondary,
                    shadowElevation = 2.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Back Button (40dp)
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier
                                .size(40.dp)
                                .testTag("chat_back_button")
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.ic_lucide_chevron_left),
                                contentDescription = "Back",
                                tint = colors.textPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        // 30dp circular avatar
                        CategoryAvatar(
                            category = category,
                            size = 32.dp
                        )

                        Spacer(modifier = Modifier.width(10.dp))

                        // Category name (16sp semibold, ellipsis)
                        Text(
                            text = category.name,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = colors.textPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )

                        // Three-dot icon button
                        Box {
                            IconButton(
                                onClick = { showSettingsMenu = true },
                                modifier = Modifier
                                    .size(40.dp)
                                    .testTag("chat_more_menu_button")
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.ic_lucide_more_vertical),
                                    contentDescription = "Settings",
                                    tint = colors.textSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            ChatSettingsMenu(
                                expanded = showSettingsMenu,
                                onDismissRequest = { showSettingsMenu = false },
                                currentSendMode = sendMode,
                                onSelectSendMode = { viewModel.setSendMode(it) },
                                showAvatars = showAvatars,
                                onToggleShowAvatars = { viewModel.setShowAvatars(!showAvatars) },
                                onOpenThemePicker = { showChatThemeDialog = true },
                                onOpenReminderCreation = {
                                    reminderPreFillNote = null
                                    showNewReminderDialog = true
                                },
                                onExportChatAsDocument = {
                                    val sb = StringBuilder()
                                    sb.append("ক্যাটাগরি: ").append(category.name).append("\n\n")
                                    for (n in notes) {
                                        val d = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault()).format(Date(n.timestamp))
                                        sb.append("[$d] ").append(n.text).append("\n")
                                    }
                                    val intent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_SUBJECT, "Notes - ${category.name}")
                                        putExtra(Intent.EXTRA_TEXT, sb.toString())
                                    }
                                    context.startActivity(Intent.createChooser(intent, "চ্যাট এক্সপোর্ট"))
                                }
                            )
                        }
                    }
                }

                // 2. Multi-Select Bar (shown when 1+ notes selected)
                if (selectedNoteIds.isNotEmpty()) {
                    Surface(
                        color = colors.bgTertiary,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { viewModel.clearSelection() },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.ic_lucide_x),
                                    contentDescription = "Cancel selection",
                                    tint = colors.textPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Text(
                                text = "${selectedNoteIds.size}টি নির্বাচিত",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = colors.textPrimary,
                                modifier = Modifier.weight(1f)
                            )

                            // Copy
                            IconButton(
                                onClick = {
                                    val textToCopy = notes
                                        .filter { selectedNoteIds.contains(it.id) }
                                        .joinToString("\n\n") { it.text }
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Notes", textToCopy))
                                    viewModel.showToast("কপি হয়েছে")
                                    viewModel.clearSelection()
                                },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.ic_lucide_copy),
                                    contentDescription = "Copy",
                                    tint = colors.textSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            // Star
                            IconButton(
                                onClick = { viewModel.starSelectedNotes() },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.ic_lucide_star),
                                    contentDescription = "Star",
                                    tint = colors.textSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            // Move
                            IconButton(
                                onClick = { showMoveDialog = true },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.ic_lucide_move),
                                    contentDescription = "Move",
                                    tint = colors.textSecondary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            // Delete
                            IconButton(
                                onClick = { viewModel.deleteSelectedNotes() },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    painter = painterResource(R.drawable.ic_lucide_trash_2),
                                    contentDescription = "Delete",
                                    tint = colors.danger,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        },
        bottomBar = {
            ChatInputBar(
                replyNote = replyNote,
                onCancelReply = { viewModel.setReplyNote(null) },
                attachedImagePath = attachedImagePath,
                onCancelAttachment = { viewModel.setAttachedImage(null) },
                onPickImage = { uri ->
                    val path = viewModel.saveImageFromUri(uri)
                    viewModel.setAttachedImage(path)
                },
                sendMode = sendMode,
                onSendNote = { text, side ->
                    viewModel.sendNote(category.id, text, side)
                }
            )
        }
    ) { paddingValues ->
        if (notes.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        painter = painterResource(R.drawable.ic_lucide_file_text),
                        contentDescription = null,
                        tint = colors.textMuted,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "এখনো কোন নোট নেই। নিচে লিখুন!",
                        fontSize = 14.5.sp,
                        color = colors.textMuted,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(vertical = 8.dp)
            ) {
                var previousDate = ""

                notes.forEach { note ->
                    val noteDateStr = SimpleDateFormat("d MMMM yyyy", Locale("bn"))
                        .format(Date(note.timestamp))

                    if (noteDateStr != previousDate) {
                        previousDate = noteDateStr
                        item(key = "date_$noteDateStr") {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(colors.bgTertiary)
                                        .padding(horizontal = 12.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = noteDateStr,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = colors.textSecondary
                                    )
                                }
                            }
                        }
                    }

                    item(key = note.id) {
                        val isSelected = selectedNoteIds.contains(note.id)
                        val reply = note.replyTo?.let { noteMap[it] }

                        ChatBubble(
                            note = note,
                            category = category,
                            replyNote = reply,
                            showAvatars = showAvatars,
                            fontSizeIndex = fontSizeIndex,
                            isSelected = isSelected,
                            onToggleSelect = { viewModel.toggleSelectNote(note.id) },
                            onReply = { viewModel.setReplyNote(note) },
                            onStar = { viewModel.toggleNoteStar(note) },
                            onEdit = { noteToEdit = note },
                            onDelete = { viewModel.deleteNote(note) },
                            onReminder = {
                                reminderPreFillNote = note
                                showNewReminderDialog = true
                            },
                            onToggleCheckbox = { updatedText ->
                                viewModel.updateNoteText(note, updatedText)
                            },
                            onJumpToNote = { targetId ->
                                val targetIndex = notes.indexOfFirst { it.id == targetId }
                                if (targetIndex != -1) {
                                    // Target index found
                                }
                            }
                        )
                    }
                }
            }
        }

        // Dialogs
        if (showChatThemeDialog) {
            ChatThemeDialog(
                currentMineColor = category.themeMine,
                currentOtherColor = category.themeOther,
                onDismiss = { showChatThemeDialog = false },
                onSave = { mine, other ->
                    viewModel.updateCategory(
                        category.copy(themeMine = mine, themeOther = other)
                    )
                }
            )
        }

        if (showNewReminderDialog) {
            NewReminderDialog(
                categories = allCategories,
                defaultCategory = category,
                defaultNote = reminderPreFillNote,
                onDismiss = { showNewReminderDialog = false },
                onSave = { head, sub, whenTime, sound, catId, noteId ->
                    viewModel.createReminder(head, sub, whenTime, sound, catId, noteId)
                },
                onPreviewSound = { sound ->
                    viewModel.previewSound(sound)
                }
            )
        }

        if (noteToEdit != null) {
            var editText by remember { mutableStateOf(noteToEdit!!.text) }
            AlertDialog(
                onDismissRequest = { noteToEdit = null },
                containerColor = colors.bgSecondary,
                title = { Text("নোট সম্পাদনা", color = colors.textPrimary, fontWeight = FontWeight.Bold) },
                text = {
                    OutlinedTextField(
                        value = editText,
                        onValueChange = { editText = it },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = colors.textPrimary,
                            unfocusedTextColor = colors.textPrimary,
                            focusedBorderColor = colors.accent,
                            unfocusedBorderColor = colors.border
                        )
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.updateNoteText(noteToEdit!!, editText)
                            noteToEdit = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = colors.accent)
                    ) {
                        Text("আপডেট", color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { noteToEdit = null }) {
                        Text("বাতিল", color = colors.textSecondary)
                    }
                }
            )
        }

        if (showMoveDialog) {
            AlertDialog(
                onDismissRequest = { showMoveDialog = false },
                containerColor = colors.bgSecondary,
                title = { Text("নোট স্থানান্তর করুন", color = colors.textPrimary, fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        allCategories.filter { it.id != category.id }.forEach { targetCat ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.moveSelectedNotes(targetCat.id)
                                        showMoveDialog = false
                                    }
                                    .padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CategoryAvatar(category = targetCat, size = 32.dp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(targetCat.name, color = colors.textPrimary, fontSize = 14.sp)
                            }
                        }
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = { showMoveDialog = false }) {
                        Text("বাতিল", color = colors.textSecondary)
                    }
                }
            )
        }
    }
}
