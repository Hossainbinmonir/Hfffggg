package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.exp
import kotlin.math.sin

object SoundPlayer {
    private const val SAMPLE_RATE = 44100
    private var alarmLoopJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    /**
     * Synthesize audio PCM 16-bit mono for given sound type
     */
    private fun generateSoundPcm(soundType: String): ShortArray {
        return when (soundType.lowercase()) {
            "beep" -> generateBeepPcm()
            "chime" -> generateChimePcm()
            "bell" -> generateBellPcm()
            "alarm" -> generateAlarmPcm()
            else -> generateBellPcm()
        }
    }

    // 3 short beeps at 880Hz (each 90ms on, 40ms off)
    private fun generateBeepPcm(): ShortArray {
        val onDuration = 0.09
        val offDuration = 0.04
        val totalSec = (onDuration + offDuration) * 3
        val totalSamples = (SAMPLE_RATE * totalSec).toInt()
        val buffer = ShortArray(totalSamples)

        val onSamples = (SAMPLE_RATE * onDuration).toInt()
        val offSamples = (SAMPLE_RATE * offDuration).toInt()
        var index = 0

        for (b in 0 until 3) {
            for (i in 0 until onSamples) {
                val t = i.toDouble() / SAMPLE_RATE
                val sample = (sin(2.0 * Math.PI * 880.0 * t) * 30000).toInt()
                if (index < totalSamples) buffer[index++] = sample.toShort()
            }
            for (i in 0 until offSamples) {
                if (index < totalSamples) buffer[index++] = 0
            }
        }
        return buffer
    }

    // 3-note ascending melody: C (523Hz), E (659Hz), G (784Hz)
    private fun generateChimePcm(): ShortArray {
        val freqs = doubleArrayOf(523.25, 659.25, 783.99)
        val noteDuration = 0.18
        val totalSec = noteDuration * 3
        val totalSamples = (SAMPLE_RATE * totalSec).toInt()
        val buffer = ShortArray(totalSamples)

        val noteSamples = (SAMPLE_RATE * noteDuration).toInt()
        var index = 0

        for (f in freqs) {
            for (i in 0 until noteSamples) {
                val t = i.toDouble() / SAMPLE_RATE
                // slight fade in/out
                val env = (1.0 - (i.toDouble() / noteSamples) * 0.4)
                val sample = (sin(2.0 * Math.PI * f * t) * env * 28000).toInt()
                if (index < totalSamples) buffer[index++] = sample.toShort()
            }
        }
        return buffer
    }

    // Bell ring at 1318Hz with decay (duration 700ms)
    private fun generateBellPcm(): ShortArray {
        val duration = 0.75
        val totalSamples = (SAMPLE_RATE * duration).toInt()
        val buffer = ShortArray(totalSamples)

        for (i in 0 until totalSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val decay = exp(-4.5 * t)
            // Fundamental + overtone harmonic for rich bell ring
            val v1 = sin(2.0 * Math.PI * 1318.5 * t) * 0.8
            val v2 = sin(2.0 * Math.PI * 2637.0 * t) * 0.2
            val sample = ((v1 + v2) * decay * 32000).toInt()
            buffer[i] = sample.toShort()
        }
        return buffer
    }

    // 6 beeps alternating 1000/800Hz
    private fun generateAlarmPcm(): ShortArray {
        val freqs = doubleArrayOf(1000.0, 800.0, 1000.0, 800.0, 1000.0, 800.0)
        val onDuration = 0.10
        val offDuration = 0.03
        val totalSec = (onDuration + offDuration) * 6
        val totalSamples = (SAMPLE_RATE * totalSec).toInt()
        val buffer = ShortArray(totalSamples)

        val onSamples = (SAMPLE_RATE * onDuration).toInt()
        val offSamples = (SAMPLE_RATE * offDuration).toInt()
        var index = 0

        for (f in freqs) {
            for (i in 0 until onSamples) {
                val t = i.toDouble() / SAMPLE_RATE
                val sample = (sin(2.0 * Math.PI * f * t) * 31000).toInt()
                if (index < totalSamples) buffer[index++] = sample.toShort()
            }
            for (i in 0 until offSamples) {
                if (index < totalSamples) buffer[index++] = 0
            }
        }
        return buffer
    }

    /**
     * Plays a single sound preview (used in Reminder dialog)
     */
    fun playPreview(soundType: String) {
        scope.launch {
            try {
                val pcm = generateSoundPcm(soundType)
                playPcmOnce(pcm, AudioAttributes.USAGE_MEDIA)
            } catch (_: Exception) {}
        }
    }

    /**
     * Starts looping alarm sound on ALARM stream every 2.6s, with vibration
     */
    fun startAlarmLoop(context: Context, soundType: String) {
        stopAlarmLoop()
        alarmLoopJob = scope.launch {
            val pcm = generateSoundPcm(soundType)
            while (isActive) {
                try {
                    vibrate(context)
                    playPcmOnce(pcm, AudioAttributes.USAGE_ALARM)
                    delay(2600)
                } catch (e: Exception) {
                    delay(1000)
                }
            }
        }
    }

    fun stopAlarmLoop() {
        alarmLoopJob?.cancel()
        alarmLoopJob = null
    }

    private fun playPcmOnce(pcm: ShortArray, usage: Int) {
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(usage)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val audioFormat = AudioFormat.Builder()
            .setSampleRate(SAMPLE_RATE)
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()

        val bufferSize = pcm.size * 2
        val track = AudioTrack.Builder()
            .setAudioAttributes(audioAttributes)
            .setAudioFormat(audioFormat)
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()

        try {
            track.write(pcm, 0, pcm.size)
            track.play()
            val durationMs = (pcm.size.toDouble() / SAMPLE_RATE * 1000).toLong() + 100
            Thread.sleep(durationMs)
        } catch (_: Exception) {
        } finally {
            try {
                track.stop()
                track.release()
            } catch (_: Exception) {}
        }
    }

    fun vibrate(context: Context) {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }

            val pattern = longArrayOf(0, 200, 100, 200, 100, 200)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, -1)
            }
        } catch (_: Exception) {}
    }
}
