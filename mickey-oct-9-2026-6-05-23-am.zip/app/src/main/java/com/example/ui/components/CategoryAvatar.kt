package com.example.ui.components

import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Category

@Composable
fun CategoryAvatar(
    category: Category,
    size: Dp = 50.dp,
    modifier: Modifier = Modifier
) {
    val categoryColor = remember(category.color) {
        try {
            Color(android.graphics.Color.parseColor(category.color))
        } catch (_: Exception) {
            Color(0xFF0084FF)
        }
    }

    val gradientBrush = remember(categoryColor) {
        Brush.linearGradient(
            colors = listOf(
                categoryColor,
                categoryColor.copy(alpha = 0.7f)
            )
        )
    }

    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(gradientBrush)
            .border(1.5.dp, categoryColor.copy(alpha = 0.4f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (!category.img.isNullOrBlank()) {
            if (category.img.startsWith("data:") || category.img.length > 200) {
                // Base64 image
                val bitmap = remember(category.img) {
                    try {
                        val base64Clean = category.img.substringAfter(",")
                        val decoded = Base64.decode(base64Clean, Base64.DEFAULT)
                        BitmapFactory.decodeByteArray(decoded, 0, decoded.size)?.asImageBitmap()
                    } catch (_: Exception) {
                        null
                    }
                }
                if (bitmap != null) {
                    androidx.compose.foundation.Image(
                        bitmap = bitmap,
                        contentDescription = category.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(size)
                    )
                } else {
                    FallbackLetter(category.name, size)
                }
            } else {
                // File or url
                AsyncImage(
                    model = category.img,
                    contentDescription = category.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(size)
                )
            }
        } else if (!category.icon.isNullOrBlank()) {
            Text(
                text = category.icon,
                fontSize = (size.value * 0.42).sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        } else {
            FallbackLetter(category.name, size)
        }
    }
}

@Composable
private fun FallbackLetter(name: String, size: Dp) {
    val initial = if (name.isNotBlank()) name.take(1) else "N"
    Text(
        text = initial,
        fontSize = (size.value * 0.42).sp,
        fontWeight = FontWeight.Bold,
        color = Color.White
    )
}
