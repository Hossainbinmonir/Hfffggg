package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R

@Composable
fun NoteRichContent(
    text: String,
    fontSize: TextUnit = 15.sp,
    textColor: Color = Color.White,
    onToggleCheckbox: ((updatedText: String) -> Unit)? = null,
    onTagClick: ((tag: String) -> Unit)? = null
) {
    val context = LocalContext.current
    val lines = text.split("\n")

    // Check if entire text or any line has checkbox format
    val hasCheckboxes = lines.any { it.startsWith("[ ]") || it.startsWith("[x]") || it.startsWith("[X]") }

    if (hasCheckboxes) {
        Column {
            lines.forEachIndexed { index, line ->
                val isUnchecked = line.startsWith("[ ]")
                val isChecked = line.startsWith("[x]") || line.startsWith("[X]")

                if (isUnchecked || isChecked) {
                    val content = line.substring(3).trimStart()
                    Row(
                        modifier = Modifier
                            .padding(vertical = 2.dp)
                            .clickable(enabled = onToggleCheckbox != null) {
                                val updatedLines = lines.toMutableList()
                                updatedLines[index] = if (isChecked) "[ ] $content" else "[x] $content"
                                onToggleCheckbox?.invoke(updatedLines.joinToString("\n"))
                            },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            painter = painterResource(
                                if (isChecked) R.drawable.ic_lucide_check_square
                                else R.drawable.ic_lucide_square
                            ),
                            contentDescription = if (isChecked) "Checked" else "Unchecked",
                            tint = if (isChecked) Color(0xFF6FD3A4) else textColor.copy(alpha = 0.7f),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        FormattedInlineText(
                            text = content,
                            fontSize = fontSize,
                            textColor = if (isChecked) textColor.copy(alpha = 0.6f) else textColor,
                            isStrikethrough = isChecked,
                            onTagClick = onTagClick
                        )
                    }
                } else if (line.isNotBlank()) {
                    FormattedInlineText(
                        text = line,
                        fontSize = fontSize,
                        textColor = textColor,
                        onTagClick = onTagClick
                    )
                }
            }
        }
    } else {
        FormattedInlineText(
            text = text,
            fontSize = fontSize,
            textColor = textColor,
            onTagClick = onTagClick
        )
    }
}

@Composable
fun FormattedInlineText(
    text: String,
    fontSize: TextUnit = 15.sp,
    textColor: Color = Color.White,
    isStrikethrough: Boolean = false,
    onTagClick: ((tag: String) -> Unit)? = null
) {
    val context = LocalContext.current
    val annotatedString = buildAnnotatedRichString(text, textColor, isStrikethrough)

    ClickableText(
        text = annotatedString,
        style = androidx.compose.ui.text.TextStyle(
            fontSize = fontSize,
            lineHeight = (fontSize.value * 1.35).sp
        ),
        onClick = { offset ->
            annotatedString.getStringAnnotations(tag = "URL", start = offset, end = offset)
                .firstOrNull()?.let { annotation ->
                    try {
                        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(annotation.item))
                        context.startActivity(browserIntent)
                    } catch (_: Exception) {}
                }

            annotatedString.getStringAnnotations(tag = "TAG", start = offset, end = offset)
                .firstOrNull()?.let { annotation ->
                    onTagClick?.invoke(annotation.item)
                }
        }
    )
}

fun buildAnnotatedRichString(
    text: String,
    textColor: Color,
    isStrikethrough: Boolean
): AnnotatedString {
    return buildAnnotatedString {
        // We will build characters with styling
        var i = 0
        val baseStyle = SpanStyle(
            color = textColor,
            textDecoration = if (isStrikethrough) TextDecoration.LineThrough else TextDecoration.None
        )

        val fullText = text
        var cursor = 0

        // Regex patterns for bold *...*, italic _..._, urls http..., #tag
        val combinedRegex = Regex("""(\*([^*]+)\*)|(_([^_]+)_)|(https?://\S+)|(#[\w\u0980-\u09FF]+)""")

        combinedRegex.findAll(fullText).forEach { match ->
            // Append preceding plain text
            if (match.range.first > cursor) {
                val plain = fullText.substring(cursor, match.range.first)
                pushStyle(baseStyle)
                append(plain)
                pop()
            }

            val value = match.value
            when {
                // Bold: *text*
                value.startsWith("*") && value.endsWith("*") && value.length > 2 -> {
                    val inner = value.substring(1, value.length - 1)
                    pushStyle(baseStyle.copy(fontWeight = FontWeight.Bold))
                    append(inner)
                    pop()
                }
                // Italic: _text_
                value.startsWith("_") && value.endsWith("_") && value.length > 2 -> {
                    val inner = value.substring(1, value.length - 1)
                    pushStyle(baseStyle.copy(fontStyle = FontStyle.Italic))
                    append(inner)
                    pop()
                }
                // URL
                value.startsWith("http://") || value.startsWith("https://") -> {
                    val start = length
                    pushStringAnnotation(tag = "URL", annotation = value)
                    pushStyle(
                        baseStyle.copy(
                            color = Color(0xFF00C6FF),
                            textDecoration = TextDecoration.Underline
                        )
                    )
                    append(value)
                    pop()
                    pop()
                }
                // #tag (supports Bengali Unicode letters)
                value.startsWith("#") -> {
                    val tag = value.substring(1)
                    pushStringAnnotation(tag = "TAG", annotation = tag)
                    pushStyle(
                        baseStyle.copy(
                            color = Color(0xFF6FD3A4),
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                    append(value)
                    pop()
                    pop()
                }
                else -> {
                    pushStyle(baseStyle)
                    append(value)
                    pop()
                }
            }
            cursor = match.range.last + 1
        }

        if (cursor < fullText.length) {
            val remaining = fullText.substring(cursor)
            pushStyle(baseStyle)
            append(remaining)
            pop()
        }
    }
}
