package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

data class DeepNoteExtendedColors(
    val bgPrimary: Color,
    val bgSecondary: Color,
    val bgTertiary: Color,
    val bgHover: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val border: Color,
    val accent: Color,
    val accentLight: Color,
    val danger: Color
)

val LocalDeepNoteColors = staticCompositionLocalOf {
    DeepNoteExtendedColors(
        bgPrimary = DarkBgPrimary,
        bgSecondary = DarkBgSecondary,
        bgTertiary = DarkBgTertiary,
        bgHover = DarkBgHover,
        textPrimary = DarkTextPrimary,
        textSecondary = DarkTextSecondary,
        textMuted = DarkTextMuted,
        border = DarkBorder,
        accent = AccentPresets[0].primary,
        accentLight = AccentPresets[0].light,
        danger = DangerColor
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    accentIndex: Int = 0,
    content: @Composable () -> Unit
) {
    val preset = AccentPresets.getOrElse(accentIndex) { AccentPresets[0] }

    val extendedColors = if (darkTheme) {
        DeepNoteExtendedColors(
            bgPrimary = DarkBgPrimary,
            bgSecondary = DarkBgSecondary,
            bgTertiary = DarkBgTertiary,
            bgHover = DarkBgHover,
            textPrimary = DarkTextPrimary,
            textSecondary = DarkTextSecondary,
            textMuted = DarkTextMuted,
            border = DarkBorder,
            accent = preset.primary,
            accentLight = preset.light,
            danger = DangerColor
        )
    } else {
        DeepNoteExtendedColors(
            bgPrimary = LightBgPrimary,
            bgSecondary = LightBgSecondary,
            bgTertiary = LightBgTertiary,
            bgHover = LightBgHover,
            textPrimary = LightTextPrimary,
            textSecondary = LightTextSecondary,
            textMuted = LightTextMuted,
            border = LightBorder,
            accent = preset.primary,
            accentLight = preset.light,
            danger = DangerColor
        )
    }

    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = preset.primary,
            secondary = preset.light,
            tertiary = preset.light,
            background = DarkBgPrimary,
            surface = DarkBgSecondary,
            surfaceVariant = DarkBgTertiary,
            onPrimary = Color.White,
            onSecondary = Color.White,
            onBackground = DarkTextPrimary,
            onSurface = DarkTextPrimary,
            outline = DarkBorder,
            error = DangerColor
        )
    } else {
        lightColorScheme(
            primary = preset.primary,
            secondary = preset.light,
            tertiary = preset.light,
            background = LightBgPrimary,
            surface = LightBgSecondary,
            surfaceVariant = LightBgTertiary,
            onPrimary = Color.White,
            onSecondary = Color.White,
            onBackground = LightTextPrimary,
            onSurface = LightTextPrimary,
            outline = LightBorder,
            error = DangerColor
        )
    }

    CompositionLocalProvider(LocalDeepNoteColors provides extendedColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}

object DeepNoteTheme {
    val colors: DeepNoteExtendedColors
        @Composable
        get() = LocalDeepNoteColors.current
}
