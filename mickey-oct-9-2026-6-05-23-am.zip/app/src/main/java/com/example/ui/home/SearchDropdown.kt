package com.example.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Category
import com.example.data.model.Note
import com.example.ui.SearchFilter
import com.example.ui.theme.DeepNoteTheme

@Composable
fun SearchBarWithResults(
    query: String,
    onQueryChange: (String) -> Unit,
    activeFilter: SearchFilter,
    onFilterChange: (SearchFilter) -> Unit,
    isFocused: Boolean,
    onFocusChange: (Boolean) -> Unit,
    results: List<Note>,
    categories: List<Category>,
    onSelectNote: (Note) -> Unit
) {
    val colors = DeepNoteTheme.colors
    val categoryMap = categories.associateBy { it.id }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
    ) {
        // Search bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(colors.bgSecondary)
                .padding(horizontal = 14.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    painter = painterResource(R.drawable.ic_lucide_search),
                    contentDescription = "Search",
                    tint = colors.textMuted,
                    modifier = Modifier.size(18.dp)
                )

                Spacer(modifier = Modifier.width(10.dp))

                Box(modifier = Modifier.weight(1f)) {
                    if (query.isEmpty()) {
                        Text(
                            text = "Search notes...",
                            fontSize = 14.sp,
                            color = colors.textMuted
                        )
                    }
                    BasicTextField(
                        value = query,
                        onValueChange = onQueryChange,
                        singleLine = true,
                        textStyle = TextStyle(
                            color = colors.textPrimary,
                            fontSize = 14.sp
                        ),
                        cursorBrush = SolidColor(colors.accent),
                        modifier = Modifier
                            .fillMaxWidth()
                            .onFocusChanged { onFocusChange(it.isFocused) }
                            .testTag("search_input")
                    )
                }

                if (query.isNotEmpty()) {
                    IconButton(
                        onClick = { onQueryChange("") },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_x),
                            contentDescription = "Clear",
                            tint = colors.textMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        // Horizontal filter chip row on focus or when query is active
        if (isFocused || query.isNotEmpty()) {
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = activeFilter == SearchFilter.IMAGE,
                    onClick = { onFilterChange(SearchFilter.IMAGE) },
                    label = { Text("Image", fontSize = 12.sp) },
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_image),
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = colors.accent,
                        selectedLabelColor = Color.White
                    )
                )

                FilterChip(
                    selected = activeFilter == SearchFilter.STAR,
                    onClick = { onFilterChange(SearchFilter.STAR) },
                    label = { Text("Star", fontSize = 12.sp) },
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_star),
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = colors.accent,
                        selectedLabelColor = Color.White
                    )
                )

                FilterChip(
                    selected = activeFilter == SearchFilter.TODAY,
                    onClick = { onFilterChange(SearchFilter.TODAY) },
                    label = { Text("Today", fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = colors.accent,
                        selectedLabelColor = Color.White
                    )
                )

                FilterChip(
                    selected = activeFilter == SearchFilter.SEVEN_DAYS,
                    onClick = { onFilterChange(SearchFilter.SEVEN_DAYS) },
                    label = { Text("7 days", fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = colors.accent,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }

        // Search Results Dropdown
        if ((query.isNotEmpty() || activeFilter != SearchFilter.ALL) && results.isNotEmpty()) {
            Spacer(modifier = Modifier.height(10.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 280.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = colors.bgSecondary),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                LazyColumn(modifier = Modifier.fillMaxWidth()) {
                    items(results) { note ->
                        val cat = categoryMap[note.categoryId]
                        SearchResultItem(
                            note = note,
                            category = cat,
                            query = query,
                            onClick = { onSelectNote(note) }
                        )
                        HorizontalDivider(
                            color = colors.border.copy(alpha = 0.4f),
                            thickness = 1.dp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SearchResultItem(
    note: Note,
    category: Category?,
    query: String,
    onClick: () -> Unit
) {
    val colors = DeepNoteTheme.colors

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            painter = painterResource(
                if (note.image != null) R.drawable.ic_lucide_image
                else if (note.star) R.drawable.ic_lucide_star
                else R.drawable.ic_lucide_file_text
            ),
            contentDescription = null,
            tint = if (note.star) colors.accent else colors.textMuted,
            modifier = Modifier.size(18.dp)
        )

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            // Highlighted match text
            val noteText = note.text.ifBlank { "ছবি নোট" }
            val annotated = buildAnnotatedString {
                val lowerText = noteText.lowercase()
                val lowerQuery = query.lowercase().trim()

                if (lowerQuery.isNotEmpty() && lowerText.contains(lowerQuery)) {
                    var start = 0
                    while (start < noteText.length) {
                        val index = lowerText.indexOf(lowerQuery, start)
                        if (index == -1) {
                            append(noteText.substring(start))
                            break
                        }
                        if (index > start) {
                            append(noteText.substring(start, index))
                        }
                        pushStyle(SpanStyle(color = colors.accentLight, fontWeight = FontWeight.Bold))
                        append(noteText.substring(index, index + lowerQuery.length))
                        pop()
                        start = index + lowerQuery.length
                    }
                } else {
                    append(noteText)
                }
            }

            Text(
                text = annotated,
                fontSize = 14.sp,
                color = colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(2.dp))

            val timeStr = java.text.SimpleDateFormat("dd MMM, hh:mm a", java.util.Locale("bn"))
                .format(java.util.Date(note.timestamp))
            Text(
                text = timeStr,
                fontSize = 11.5.sp,
                color = colors.textMuted
            )
        }

        // Category badge
        if (category != null) {
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(colors.bgTertiary)
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = category.name,
                    fontSize = 11.sp,
                    color = colors.accentLight,
                    maxLines = 1
                )
            }
        }
    }
}
