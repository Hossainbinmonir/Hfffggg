package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBgPrimary = Color(0xFF0F1114)
val DarkBgSecondary = Color(0xFF181B20)
val DarkBgTertiary = Color(0xFF20242A)
val DarkBgHover = Color(0xFF2D323A)
val DarkTextPrimary = Color(0xFFFFFFFF)
val DarkTextSecondary = Color(0xFFA9B0BA)
val DarkTextMuted = Color(0xFF6B7480)
val DarkBorder = Color(0xFF20242A)

val LightBgPrimary = Color(0xFFFFFFFF)
val LightBgSecondary = Color(0xFFF4F5F7)
val LightBgTertiary = Color(0xFFEAECF0)
val LightBgHover = Color(0xFFDDE0E6)
val LightTextPrimary = Color(0xFF050505)
val LightTextSecondary = Color(0xFF65676B)
val LightTextMuted = Color(0xFF8A8D91)
val LightBorder = Color(0xFFEAECF0)

val DangerColor = Color(0xFFFA3E3E)

// Accent Presets
data class AccentPreset(
    val name: String,
    val primary: Color,
    val light: Color
)

val AccentPresets = listOf(
    AccentPreset("Blue", Color(0xFF0084FF), Color(0xFF00C6FF)),
    AccentPreset("Slate", Color(0xFF5B7C99), Color(0xFF8FB3D1)),
    AccentPreset("Green", Color(0xFF2E9E6B), Color(0xFF6FD3A4)),
    AccentPreset("Purple", Color(0xFF7A5AF8), Color(0xFFB39DFC))
)
