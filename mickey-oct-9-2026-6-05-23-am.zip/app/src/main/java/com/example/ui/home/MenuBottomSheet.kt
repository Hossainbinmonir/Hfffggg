package com.example.ui.home

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.R
import com.example.ui.theme.DeepNoteTheme
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuBottomSheet(
    onDismiss: () -> Unit,
    pendingReminderCount: Int,
    isArchivedView: Boolean,
    onToggleArchivedView: () -> Unit,
    isReorderMode: Boolean,
    onToggleReorderMode: () -> Unit,
    fontSize: Int,
    onFontSizeChange: (Int) -> Unit,
    hasPin: Boolean,
    onOpenPinSetup: () -> Unit,
    remind7dBackup: Boolean,
    onToggle7dBackup: (Boolean) -> Unit,
    storageUsage: Pair<String, String>,
    onOpenAllReminders: () -> Unit,
    onNewReminder: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onExportBackup: () -> Unit,
    onImportBackupFile: (Uri) -> Unit,
    onExportAllNotesText: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val colors = DeepNoteTheme.colors
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val importPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            onImportBackupFile(uri)
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = colors.bgSecondary,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 22.dp, vertical = 12.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(
                text = "মেনু",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )

            Spacer(modifier = Modifier.height(16.dp))

            // SECTION: রিমাইন্ডার
            MenuSectionHeader(title = "রিমাইন্ডার")

            MenuItemRow(
                iconRes = R.drawable.ic_lucide_bell,
                label = "সব রিমাইন্ডার দেখুন",
                badge = if (pendingReminderCount > 0) "$pendingReminderCount" else null,
                onClick = {
                    onDismiss()
                    onOpenAllReminders()
                }
            )

            MenuItemRow(
                iconRes = R.drawable.ic_lucide_plus,
                label = "নতুন রিমাইন্ডার",
                onClick = {
                    onDismiss()
                    onNewReminder()
                }
            )

            MenuItemRow(
                iconRes = R.drawable.ic_lucide_power,
                label = "নোটিফিকেশন চালু করুন",
                onClick = onRequestNotificationPermission
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = colors.border)

            // SECTION: ডেটা
            MenuSectionHeader(title = "ডেটা")

            MenuItemRow(
                iconRes = R.drawable.ic_lucide_download,
                label = "ব্যাকআপ এক্সপোর্ট (JSON)",
                onClick = {
                    onExportBackup()
                }
            )

            MenuItemRow(
                iconRes = R.drawable.ic_lucide_upload,
                label = "ব্যাকআপ ইমপোর্ট",
                onClick = {
                    importPickerLauncher.launch("application/json")
                }
            )

            MenuItemRow(
                iconRes = R.drawable.ic_lucide_file_text,
                label = "সব নোট টেক্সট ফাইলে",
                onClick = onExportAllNotesText
            )

            MenuItemRow(
                iconRes = R.drawable.ic_lucide_file_text,
                label = "PDF হিসেবে সেভ (সব নোট)",
                onClick = onExportAllNotesText // Shared text/doc output
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = colors.border)

            // SECTION: দেখা
            MenuSectionHeader(title = "দেখা")

            MenuItemRow(
                iconRes = R.drawable.ic_lucide_archive,
                label = if (isArchivedView) "সব ক্যাটাগরিতে ফিরুন" else "আর্কাইভ দেখুন",
                onClick = {
                    onToggleArchivedView()
                    onDismiss()
                }
            )

            MenuItemRow(
                iconRes = R.drawable.ic_lucide_grip_vertical,
                label = if (isReorderMode) "সাজানো সম্পন্ন" else "ক্যাটাগরি সাজান",
                onClick = {
                    onToggleReorderMode()
                    onDismiss()
                }
            )

            // Font size selector
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "লেখার সাইজ:",
                    fontSize = 14.5.sp,
                    color = colors.textPrimary
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = fontSize == 0,
                        onClick = { onFontSizeChange(0) },
                        label = { Text("ছোট", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = colors.accent,
                            selectedLabelColor = Color.White
                        )
                    )
                    FilterChip(
                        selected = fontSize == 1,
                        onClick = { onFontSizeChange(1) },
                        label = { Text("মাঝারি", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = colors.accent,
                            selectedLabelColor = Color.White
                        )
                    )
                    FilterChip(
                        selected = fontSize == 2,
                        onClick = { onFontSizeChange(2) },
                        label = { Text("বড়", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = colors.accent,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = colors.border)

            // SECTION: নিরাপত্তা
            MenuSectionHeader(title = "নিরাপত্তা")

            MenuItemRow(
                iconRes = if (hasPin) R.drawable.ic_lucide_unlock else R.drawable.ic_lucide_lock,
                label = if (hasPin) "PIN লক বন্ধ বা পরিবর্তন করুন" else "PIN লক সেট করুন",
                onClick = {
                    onDismiss()
                    onOpenPinSetup()
                }
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        painter = painterResource(R.drawable.ic_lucide_clock),
                        contentDescription = null,
                        tint = colors.textSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "৭ দিনের ব্যাকআপ রিমাইন্ডার",
                        fontSize = 14.sp,
                        color = colors.textPrimary
                    )
                }

                Switch(
                    checked = remind7dBackup,
                    onCheckedChange = onToggle7dBackup,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = colors.accent
                    )
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = colors.border)

            // SECTION: স্টোরেজ
            MenuSectionHeader(title = "স্টোরেজ")
            Spacer(modifier = Modifier.height(6.dp))

            LinearProgressIndicator(
                progress = { 0.15f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = colors.accent,
                trackColor = colors.bgTertiary
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "ব্যবহৃত ${storageUsage.first} MB / উপলব্ধ ${storageUsage.second} GB",
                fontSize = 12.sp,
                color = colors.textMuted
            )

            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}

@Composable
fun MenuSectionHeader(title: String) {
    Text(
        text = title,
        fontSize = 12.5.sp,
        fontWeight = FontWeight.Bold,
        color = DeepNoteTheme.colors.accentLight,
        letterSpacing = 0.5.sp,
        modifier = Modifier.padding(vertical = 4.dp)
    )
}

@Composable
fun MenuItemRow(
    iconRes: Int,
    label: String,
    badge: String? = null,
    onClick: () -> Unit
) {
    val colors = DeepNoteTheme.colors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            painter = painterResource(iconRes),
            contentDescription = null,
            tint = colors.textSecondary,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = label,
            fontSize = 14.5.sp,
            color = colors.textPrimary,
            modifier = Modifier.weight(1f)
        )
        if (badge != null) {
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(colors.danger)
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = badge,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}
