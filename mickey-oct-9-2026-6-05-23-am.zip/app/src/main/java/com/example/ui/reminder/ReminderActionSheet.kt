package com.example.ui.reminder

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Reminder
import com.example.ui.theme.DeepNoteTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReminderActionSheet(
    reminder: Reminder,
    onDismiss: () -> Unit,
    onOpenLinkedNote: () -> Unit,
    onToggleDone: () -> Unit,
    onTriggerAgain: () -> Unit,
    onDelete: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val colors = DeepNoteTheme.colors

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = colors.bgSecondary,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 22.dp, vertical = 12.dp)
        ) {
            Text(
                text = reminder.head,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )
            if (reminder.sub.isNotBlank()) {
                Text(
                    text = reminder.sub,
                    fontSize = 13.5.sp,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = colors.border)

            if (!reminder.catId.isNullOrBlank()) {
                ActionSheetRow(
                    iconRes = R.drawable.ic_lucide_file_text,
                    title = "নোট খুলুন",
                    onClick = {
                        onDismiss()
                        onOpenLinkedNote()
                    }
                )
            }

            ActionSheetRow(
                iconRes = if (reminder.done) R.drawable.ic_lucide_x else R.drawable.ic_lucide_check,
                title = if (reminder.done) "অসম্পূর্ণ চিহ্নিত করুন" else "সম্পন্ন চিহ্নিত করুন",
                onClick = {
                    onDismiss()
                    onToggleDone()
                }
            )

            if (reminder.fired || reminder.whenTime <= System.currentTimeMillis()) {
                ActionSheetRow(
                    iconRes = R.drawable.ic_lucide_bell_ringing,
                    title = "আবার বাজান (Trigger again)",
                    onClick = {
                        onDismiss()
                        onTriggerAgain()
                    }
                )
            }

            ActionSheetRow(
                iconRes = R.drawable.ic_lucide_trash_2,
                title = "মুছুন",
                isDestructive = true,
                onClick = {
                    onDismiss()
                    onDelete()
                }
            )

            Spacer(modifier = Modifier.size(24.dp))
        }
    }
}

@Composable
fun ActionSheetRow(
    iconRes: Int,
    title: String,
    isDestructive: Boolean = false,
    onClick: () -> Unit
) {
    val colors = DeepNoteTheme.colors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            painter = painterResource(iconRes),
            contentDescription = null,
            tint = if (isDestructive) colors.danger else colors.textSecondary,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(14.dp))
        Text(
            text = title,
            fontSize = 15.sp,
            color = if (isDestructive) colors.danger else colors.textPrimary,
            fontWeight = if (isDestructive) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}
