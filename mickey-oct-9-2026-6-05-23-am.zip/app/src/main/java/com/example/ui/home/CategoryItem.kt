package com.example.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Category
import com.example.data.model.Note
import com.example.ui.components.CategoryAvatar
import com.example.ui.theme.DeepNoteTheme

@Composable
fun CategoryItem(
    category: Category,
    lastNote: Note?,
    noteCount: Int,
    isReorderMode: Boolean,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onTogglePin: (() -> Unit)? = null,
    onToggleArchive: (() -> Unit)? = null
) {
    val colors = DeepNoteTheme.colors
    var showMenu by remember { mutableStateOf(false) }

    val previewText = remember(lastNote) {
        when {
            lastNote == null -> "কোন নোট নেই"
            !lastNote.image.isNullOrBlank() -> "ছবি"
            lastNote.text.isNotBlank() -> lastNote.text.replace("\n", " ")
            else -> "কোন নোট নেই"
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .testTag("category_row_${category.id}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = colors.bgSecondary
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isReorderMode) {
                Column(
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(end = 12.dp)
                ) {
                    IconButton(
                        onClick = onMoveUp,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_move),
                            contentDescription = "Move Up",
                            tint = colors.textSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // 50dp circular avatar
            CategoryAvatar(category = category, size = 50.dp)

            Spacer(modifier = Modifier.width(14.dp))

            // Title & Preview
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (category.pin) {
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_star),
                            contentDescription = "Pinned",
                            tint = Color(0xFFFFD700),
                            modifier = Modifier
                                .size(15.dp)
                                .padding(end = 4.dp)
                        )
                    }
                    Text(
                        text = category.name,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.height(3.dp))

                Text(
                    text = previewText,
                    fontSize = 13.5.sp,
                    color = colors.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Note count badge
            if (noteCount > 0) {
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(colors.bgTertiary)
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "$noteCount",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.accentLight
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
            }

            // Action Menu Icon
            Box {
                IconButton(
                    onClick = { showMenu = true },
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("category_menu_${category.id}")
                ) {
                    Icon(
                        painter = painterResource(R.drawable.ic_lucide_more_vertical),
                        contentDescription = "Category options",
                        tint = colors.textMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }

                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false },
                    modifier = Modifier.background(colors.bgTertiary)
                ) {
                    DropdownMenuItem(
                        text = { Text("সম্পাদনা", color = colors.textPrimary) },
                        leadingIcon = {
                            Icon(
                                painter = painterResource(R.drawable.ic_lucide_pencil),
                                contentDescription = null,
                                tint = colors.textSecondary
                            )
                        },
                        onClick = {
                            showMenu = false
                            onEdit()
                        }
                    )

                    if (onTogglePin != null) {
                        DropdownMenuItem(
                            text = { Text(if (category.pin) "আনপিন করুন" else "পিন করুন", color = colors.textPrimary) },
                            leadingIcon = {
                                Icon(
                                    painter = painterResource(R.drawable.ic_lucide_star),
                                    contentDescription = null,
                                    tint = if (category.pin) Color(0xFFFFD700) else colors.textSecondary
                                )
                            },
                            onClick = {
                                showMenu = false
                                onTogglePin()
                            }
                        )
                    }

                    if (onToggleArchive != null) {
                        DropdownMenuItem(
                            text = { Text(if (category.arch) "আনআর্কাইভ" else "আর্কাইভ করুন", color = colors.textPrimary) },
                            leadingIcon = {
                                Icon(
                                    painter = painterResource(R.drawable.ic_lucide_archive),
                                    contentDescription = null,
                                    tint = colors.textSecondary
                                )
                            },
                            onClick = {
                                showMenu = false
                                onToggleArchive()
                            }
                        )
                    }

                    DropdownMenuItem(
                        text = { Text("মুছুন", color = colors.danger) },
                        leadingIcon = {
                            Icon(
                                painter = painterResource(R.drawable.ic_lucide_trash_2),
                                contentDescription = null,
                                tint = colors.danger
                            )
                        },
                        onClick = {
                            showMenu = false
                            onDelete()
                        }
                    )
                }
            }
        }
    }
}
