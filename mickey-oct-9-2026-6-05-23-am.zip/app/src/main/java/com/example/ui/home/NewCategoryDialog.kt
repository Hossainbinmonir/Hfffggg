package com.example.ui.home

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Category
import com.example.ui.theme.DeepNoteTheme

@Composable
fun NewCategoryDialog(
    categoryToEdit: Category? = null,
    onDismiss: () -> Unit,
    onSave: (name: String, icon: String?, img: String?, color: String) -> Unit,
    onPickImage: (Uri) -> String?
) {
    var name by remember { mutableStateOf(categoryToEdit?.name ?: "") }
    var selectedIcon by remember { mutableStateOf(categoryToEdit?.icon ?: "📝") }
    var selectedColor by remember { mutableStateOf(categoryToEdit?.color ?: "#0084FF") }
    var imagePath by remember { mutableStateOf(categoryToEdit?.img) }
    var errorText by remember { mutableStateOf<String?>(null) }
    val colors = DeepNoteTheme.colors

    val emojiList = listOf("📝", "💡", "💼", "🎯", "🚀", "❤️", "📚", "☕", "🎨", "🌿", "⭐", "🔒")
    val colorPresets = listOf("#0084FF", "#2E9E6B", "#7A5AF8", "#FA3E3E", "#F59E0B", "#EC4899", "#5B7C99")

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val path = onPickImage(uri)
            if (path != null) {
                imagePath = path
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = colors.bgSecondary,
        title = {
            Text(
                text = if (categoryToEdit == null) "নতুন ক্যাটাগরি তৈরি করুন" else "ক্যাটাগরি সম্পাদনা",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = colors.textPrimary
            )
        },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        errorText = null
                    },
                    label = { Text("ক্যাটাগরির নাম") },
                    placeholder = { Text("যেমন: ব্যক্তিগত নোট, আইডিয়া...") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = colors.textPrimary,
                        unfocusedTextColor = colors.textPrimary,
                        focusedBorderColor = colors.accent,
                        unfocusedBorderColor = colors.border
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("category_name_input")
                )

                if (errorText != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = errorText!!, color = colors.danger, fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Icon / Emoji selector
                Text(
                    text = "আইকন নির্বাচন করুন:",
                    fontSize = 13.sp,
                    color = colors.textSecondary
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(emojiList) { emoji ->
                        val isSelected = selectedIcon == emoji && imagePath == null
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) colors.accent else colors.bgTertiary)
                                .border(
                                    1.dp,
                                    if (isSelected) colors.accentLight else colors.border,
                                    CircleShape
                                )
                                .clickable {
                                    selectedIcon = emoji
                                    imagePath = null
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = emoji, fontSize = 18.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Color presets
                Text(
                    text = "কালার থিম:",
                    fontSize = 13.sp,
                    color = colors.textSecondary
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(colorPresets) { hex ->
                        val isSelected = selectedColor.equals(hex, ignoreCase = true)
                        val c = try {
                            Color(android.graphics.Color.parseColor(hex))
                        } catch (_: Exception) {
                            colors.accent
                        }
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(c)
                                .border(
                                    2.dp,
                                    if (isSelected) Color.White else Color.Transparent,
                                    CircleShape
                                )
                                .clickable { selectedColor = hex },
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Icon(
                                    painter = painterResource(R.drawable.ic_lucide_check),
                                    contentDescription = "Selected",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Upload custom photo
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(
                        onClick = { photoPickerLauncher.launch("image/*") },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("upload_avatar_button")
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_image),
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (imagePath == null) "ছবি আপলোড" else "ছবি পরিবর্তন",
                            fontSize = 12.5.sp
                        )
                    }

                    if (imagePath != null) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "যুক্ত হয়েছে",
                            fontSize = 12.sp,
                            color = colors.accentLight
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) {
                        errorText = "ক্যাটাগরির নাম দিন"
                    } else {
                        onSave(name.trim(), selectedIcon, imagePath, selectedColor)
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("save_category_button")
            ) {
                Text(text = "সেভ করুন", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল", color = colors.textSecondary)
            }
        }
    )
}
