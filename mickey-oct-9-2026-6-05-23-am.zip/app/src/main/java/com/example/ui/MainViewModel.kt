package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.alarm.AlarmScheduler
import com.example.alarm.NotificationHelper
import com.example.audio.SoundPlayer
import com.example.data.local.AppDatabase
import com.example.data.model.Category
import com.example.data.model.Note
import com.example.data.model.Reminder
import com.example.data.preferences.AppPreferences
import com.example.data.repository.DeepNoteRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

enum class AppScreen {
    HOME,
    CHAT,
    REMINDERS
}

enum class SearchFilter {
    ALL,
    IMAGE,
    STAR,
    TODAY,
    SEVEN_DAYS
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val preferences = AppPreferences(application)
    val repository = DeepNoteRepository(
        db.categoryDao(),
        db.noteDao(),
        db.reminderDao(),
        preferences
    )

    // Navigation
    private val _currentScreen = MutableStateFlow(AppScreen.HOME)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _activeCategoryId = MutableStateFlow<String?>(null)
    val activeCategoryId: StateFlow<String?> = _activeCategoryId.asStateFlow()

    // PIN Lock
    private val _isUnlocked = MutableStateFlow(false)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    val userPin: StateFlow<String?> = preferences.pinFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    // Preferences
    val appTitle: StateFlow<String> = preferences.titleFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "NoteBook")

    val appTheme: StateFlow<String> = preferences.themeFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "dark")

    val sendMode: StateFlow<String> = preferences.modeFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "single")

    val showAvatars: StateFlow<Boolean> = preferences.showAvatarsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val fontSize: StateFlow<Int> = preferences.fontSizeFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 1)

    val accentIndex: StateFlow<Int> = preferences.accentIndexFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val remindBackup: StateFlow<Boolean> = preferences.remindBackupFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    // Archive view mode
    private val _showArchived = MutableStateFlow(false)
    val showArchived: StateFlow<Boolean> = _showArchived.asStateFlow()

    // Categories
    val categories: StateFlow<List<Category>> = combine(
        repository.activeCategories,
        repository.archivedCategories,
        _showArchived
    ) { active, archived, showArch ->
        if (showArch) archived else active
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCategoriesList: StateFlow<List<Category>> = repository.allCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // All notes for quick previews/counts
    val allNotes: StateFlow<List<Note>> = db.noteDao().getAllNotes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Category in Chat
    @OptIn(ExperimentalCoroutinesApi::class)
    val currentCategory: StateFlow<Category?> = _activeCategoryId.flatMapLatest { id ->
        if (id == null) flowOf(null) else repository.getCategoryById(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val currentNotes: StateFlow<List<Note>> = _activeCategoryId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else repository.getNotesForCategory(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Reminders
    val allReminders: StateFlow<List<Reminder>> = repository.allReminders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val upcomingReminderCount: StateFlow<Int> = repository.upcomingCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val firedOrDueCount: StateFlow<Int> = repository.firedOrDueCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Multi-Select in Chat
    private val _selectedNoteIds = MutableStateFlow<Set<String>>(emptySet())
    val selectedNoteIds: StateFlow<Set<String>> = _selectedNoteIds.asStateFlow()

    // Reply & Attachment in Chat
    private val _replyNote = MutableStateFlow<Note?>(null)
    val replyNote: StateFlow<Note?> = _replyNote.asStateFlow()

    private val _attachedImagePath = MutableStateFlow<String?>(null)
    val attachedImagePath: StateFlow<String?> = _attachedImagePath.asStateFlow()

    // Search
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchFilter = MutableStateFlow(SearchFilter.ALL)
    val searchFilter: StateFlow<SearchFilter> = _searchFilter.asStateFlow()

    private val _isSearchFocused = MutableStateFlow(false)
    val isSearchFocused: StateFlow<Boolean> = _isSearchFocused.asStateFlow()

    @OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
    val searchResults: StateFlow<List<Note>> = combine(
        _searchQuery.debounce(250),
        _searchFilter,
        allNotes
    ) { query, filter, notes ->
        if (query.isBlank() && filter == SearchFilter.ALL) {
            emptyList()
        } else {
            val now = System.currentTimeMillis()
            val dayMs = 24 * 60 * 60 * 1000L
            val sevenDaysMs = 7 * dayMs

            notes.filter { note ->
                val matchesQuery = query.isBlank() || note.text.contains(query, ignoreCase = true)
                val matchesFilter = when (filter) {
                    SearchFilter.ALL -> true
                    SearchFilter.IMAGE -> !note.image.isNullOrBlank()
                    SearchFilter.STAR -> note.star
                    SearchFilter.TODAY -> (now - note.timestamp) <= dayMs
                    SearchFilter.SEVEN_DAYS -> (now - note.timestamp) <= sevenDaysMs
                }
                matchesQuery && matchesFilter
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Reorder mode on Home
    private val _isReorderMode = MutableStateFlow(false)
    val isReorderMode: StateFlow<Boolean> = _isReorderMode.asStateFlow()

    // Toast event
    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    init {
        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
        }
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    // Navigation
    fun navigateToHome() {
        _currentScreen.value = AppScreen.HOME
        _activeCategoryId.value = null
        clearSelection()
        _replyNote.value = null
        _attachedImagePath.value = null
    }

    fun navigateToChat(categoryId: String) {
        _activeCategoryId.value = categoryId
        _currentScreen.value = AppScreen.CHAT
        clearSelection()
        _replyNote.value = null
        _attachedImagePath.value = null
    }

    fun navigateToReminders() {
        _currentScreen.value = AppScreen.REMINDERS
    }

    // PIN Lock
    fun unlock(pin: String): Boolean {
        val stored = userPin.value
        return if (stored == null || stored == pin) {
            _isUnlocked.value = true
            true
        } else {
            false
        }
    }

    fun setPin(pin: String?) {
        viewModelScope.launch {
            preferences.setPin(pin)
            if (pin != null) {
                showToast("PIN লক চালু হয়েছে")
            } else {
                showToast("PIN লক বন্ধ হয়েছে")
            }
        }
    }

    // Theme & Title
    fun toggleTheme() {
        viewModelScope.launch {
            val current = appTheme.value
            val next = if (current == "dark") "light" else "dark"
            preferences.setTheme(next)
        }
    }

    fun updateTitleAndAccent(newTitle: String, newAccentIndex: Int) {
        viewModelScope.launch {
            preferences.setTitle(newTitle)
            preferences.setAccentIndex(newAccentIndex)
            showToast("আপডেট সম্পন্ন হয়েছে")
        }
    }

    fun setSendMode(mode: String) {
        viewModelScope.launch {
            preferences.setMode(mode)
        }
    }

    fun setShowAvatars(show: Boolean) {
        viewModelScope.launch {
            preferences.setShowAvatars(show)
        }
    }

    fun setFontSize(size: Int) {
        viewModelScope.launch {
            preferences.setFontSize(size)
        }
    }

    fun toggleArchivedView() {
        _showArchived.value = !_showArchived.value
    }

    fun toggleReorderMode() {
        _isReorderMode.value = !_isReorderMode.value
    }

    // Search
    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSearchFilter(filter: SearchFilter) {
        _searchFilter.value = if (_searchFilter.value == filter) SearchFilter.ALL else filter
    }

    fun setSearchFocused(focused: Boolean) {
        _isSearchFocused.value = focused
    }

    // Categories
    fun createCategory(
        name: String,
        icon: String?,
        img: String?,
        color: String
    ) {
        viewModelScope.launch {
            repository.createCategory(
                name = name,
                icon = icon,
                img = img,
                color = color
            )
            showToast("ক্যাটাগরি তৈরি হয়েছে")
        }
    }

    fun updateCategory(category: Category) {
        viewModelScope.launch {
            repository.updateCategory(category)
            showToast("ক্যাটাগরি আপডেট হয়েছে")
        }
    }

    fun deleteCategory(category: Category) {
        viewModelScope.launch {
            repository.deleteCategory(category)
            showToast("ক্যাটাগরি ডিলিট হয়েছে")
        }
    }

    fun toggleCategoryPin(category: Category) {
        viewModelScope.launch {
            repository.togglePin(category.id, category.pin)
        }
    }

    fun toggleCategoryArchive(category: Category) {
        viewModelScope.launch {
            repository.toggleArchive(category.id, category.arch)
            showToast(if (!category.arch) "আর্কাইভ করা হয়েছে" else "ফিরিয়ে আনা হয়েছে")
        }
    }

    fun reorderCategory(id: String, newOrd: Int) {
        viewModelScope.launch {
            repository.updateCategoryOrder(id, newOrd)
        }
    }

    // Chat / Notes
    fun sendNote(
        categoryId: String,
        text: String,
        forceSide: String? = null
    ) {
        if (text.isBlank() && _attachedImagePath.value == null) return

        viewModelScope.launch {
            val mode = sendMode.value
            val side = when {
                forceSide != null -> forceSide
                mode == "single" -> "right"
                mode == "auto" -> {
                    val count = preferences.incrementAutoCounter()
                    if (count % 2 == 0) "left" else "right"
                }
                else -> "right"
            }

            repository.createNote(
                categoryId = categoryId,
                text = text.trim(),
                side = side,
                image = _attachedImagePath.value,
                replyTo = _replyNote.value?.id
            )

            _replyNote.value = null
            _attachedImagePath.value = null
        }
    }

    fun updateNoteText(note: Note, newText: String) {
        viewModelScope.launch {
            repository.updateNote(note.copy(text = newText))
            showToast("নোট আপডেট হয়েছে")
        }
    }

    fun toggleNoteStar(note: Note) {
        viewModelScope.launch {
            repository.toggleStar(note.id, note.star)
        }
    }

    fun deleteNote(note: Note) {
        viewModelScope.launch {
            repository.deleteNote(note)
            showToast("নোট ডিলিট হয়েছে")
        }
    }

    fun setReplyNote(note: Note?) {
        _replyNote.value = note
    }

    fun setAttachedImage(path: String?) {
        _attachedImagePath.value = path
        if (path != null) {
            showToast("ছবি যুক্ত হয়েছে")
        }
    }

    // Selection
    fun toggleSelectNote(noteId: String) {
        val current = _selectedNoteIds.value.toMutableSet()
        if (current.contains(noteId)) {
            current.remove(noteId)
        } else {
            current.add(noteId)
        }
        _selectedNoteIds.value = current
    }

    fun clearSelection() {
        _selectedNoteIds.value = emptySet()
    }

    fun deleteSelectedNotes() {
        val ids = _selectedNoteIds.value.toList()
        viewModelScope.launch {
            repository.deleteNotes(ids)
            clearSelection()
            showToast("নোট ডিলিট হয়েছে")
        }
    }

    fun starSelectedNotes() {
        val ids = _selectedNoteIds.value
        viewModelScope.launch {
            val notes = currentNotes.value.filter { ids.contains(it.id) }
            for (n in notes) {
                repository.toggleStar(n.id, false)
            }
            clearSelection()
            showToast("নোট স্টার করা হয়েছে")
        }
    }

    fun moveSelectedNotes(targetCategoryId: String) {
        val ids = _selectedNoteIds.value.toList()
        viewModelScope.launch {
            repository.moveNotes(ids, targetCategoryId)
            clearSelection()
            showToast("নোট স্থানান্তর সম্পন্ন হয়েছে")
        }
    }

    // Save image to internal storage compressed
    fun saveImageFromUri(uri: Uri): String? {
        val context = getApplication<Application>()
        return try {
            val inputStream = context.contentResolver.openInputStream(uri) ?: return null
            val bitmap = BitmapFactory.decodeStream(inputStream)
            inputStream.close()

            // Scale to max 1024px
            val maxSide = 1024
            val width = bitmap.width
            val height = bitmap.height
            val scaledBitmap = if (width > maxSide || height > maxSide) {
                val ratio = if (width > height) maxSide.toFloat() / width else maxSide.toFloat() / height
                Bitmap.createScaledBitmap(bitmap, (width * ratio).toInt(), (height * ratio).toInt(), true)
            } else {
                bitmap
            }

            val imagesDir = File(context.filesDir, "images")
            if (!imagesDir.exists()) imagesDir.mkdirs()

            val file = File(imagesDir, "${UUID.randomUUID()}.jpg")
            val outputStream = FileOutputStream(file)
            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 75, outputStream)
            outputStream.flush()
            outputStream.close()

            file.absolutePath
        } catch (e: Exception) {
            showToast("ছবি লোড করা যায়নি")
            null
        }
    }

    // Reminders
    fun createReminder(
        head: String,
        sub: String,
        whenTime: Long,
        sound: String,
        catId: String?,
        noteId: String? = null
    ) {
        if (head.isBlank()) {
            showToast("হেডার দিন")
            return
        }
        if (whenTime <= System.currentTimeMillis()) {
            showToast("অতীতের সময় দেওয়া যাবে না")
            return
        }

        viewModelScope.launch {
            val context = getApplication<Application>()
            val reminder = repository.createReminder(
                head = head.trim(),
                sub = sub.trim(),
                whenTime = whenTime,
                sound = sound,
                catId = catId,
                noteId = noteId
            )
            AlarmScheduler.scheduleReminder(context, reminder)

            val timeStr = java.text.SimpleDateFormat("hh:mm a", java.util.Locale("bn")).format(java.util.Date(whenTime))
            showToast("রিমাইন্ডার সেট হয়েছে — $timeStr")
            NotificationHelper.showConfirmationNotification(context, head, timeStr)
        }
    }

    fun updateReminder(reminder: Reminder) {
        viewModelScope.launch {
            val context = getApplication<Application>()
            repository.updateReminder(reminder)
            if (!reminder.done && reminder.whenTime > System.currentTimeMillis()) {
                AlarmScheduler.scheduleReminder(context, reminder)
            }
            val timeStr = java.text.SimpleDateFormat("hh:mm a", java.util.Locale("bn")).format(java.util.Date(reminder.whenTime))
            showToast("রিমাইন্ডার আপডেট হয়েছে — $timeStr")
        }
    }

    fun deleteReminder(reminder: Reminder) {
        viewModelScope.launch {
            val context = getApplication<Application>()
            AlarmScheduler.cancelReminder(context, reminder.id)
            repository.deleteReminder(reminder.id)
            showToast("রিমাইন্ডার ডিলিট হয়েছে")
        }
    }

    fun toggleReminderDone(reminder: Reminder) {
        viewModelScope.launch {
            val context = getApplication<Application>()
            val newDone = !reminder.done
            repository.setReminderDone(reminder.id, newDone)
            if (newDone) {
                AlarmScheduler.cancelReminder(context, reminder.id)
            } else if (reminder.whenTime > System.currentTimeMillis()) {
                AlarmScheduler.scheduleReminder(context, reminder.copy(done = false))
            }
        }
    }

    fun snoozeReminder(reminder: Reminder, minutes: Int) {
        viewModelScope.launch {
            val context = getApplication<Application>()
            repository.snoozeReminder(reminder.id, minutes)
            val updated = repository.getReminderById(reminder.id)
            if (updated != null) {
                AlarmScheduler.scheduleReminder(context, updated)
            }
            showToast("স্নুজ: $minutes মিনিট পর আবার")
        }
    }

    fun previewSound(soundType: String) {
        SoundPlayer.playPreview(soundType)
    }

    // Backup & Restore
    suspend fun exportBackupJson(): String = repository.exportBackupJson()

    suspend fun importBackupJson(json: String): Result<Int> {
        val result = repository.importBackupJson(json)
        if (result.isSuccess) {
            // Reschedule pending alarms
            val context = getApplication<Application>()
            val pending = db.reminderDao().getPendingToSchedule(System.currentTimeMillis())
            for (r in pending) {
                AlarmScheduler.scheduleReminder(context, r)
            }
        }
        return result
    }

    suspend fun exportAllNotesAsText(): String = repository.exportAllNotesAsText()

    fun getStorageUsage(): Pair<String, String> {
        val context = getApplication<Application>()
        return try {
            val dbFile = context.getDatabasePath("deepnote_database")
            val imagesDir = File(context.filesDir, "images")
            var totalBytes = if (dbFile.exists()) dbFile.length() else 0L
            if (imagesDir.exists()) {
                imagesDir.listFiles()?.forEach { totalBytes += it.length() }
            }
            val usedMb = String.format(java.util.Locale.US, "%.1f", totalBytes / (1024.0 * 1024.0))

            val stat = android.os.StatFs(context.filesDir.path)
            val availableBytes = stat.availableBlocksLong * stat.blockSizeLong
            val freeGb = String.format(java.util.Locale.US, "%.1f", availableBytes / (1024.0 * 1024.0 * 1024.0))

            Pair(usedMb, freeGb)
        } catch (_: Exception) {
            Pair("0.5", "10.0")
        }
    }
}
