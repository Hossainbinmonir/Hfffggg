package com.example.ui.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.DeepNoteTheme

@Composable
fun ChatSettingsMenu(
    expanded: Boolean,
    onDismissRequest: () -> Unit,
    currentSendMode: String,
    onSelectSendMode: (String) -> Unit,
    showAvatars: Boolean,
    onToggleShowAvatars: () -> Unit,
    onOpenThemePicker: () -> Unit,
    onOpenReminderCreation: () -> Unit,
    onExportChatAsDocument: () -> Unit
) {
    val colors = DeepNoteTheme.colors

    DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismissRequest,
        modifier = Modifier.background(colors.bgSecondary)
    ) {
        // Send modes
        DropdownMenuItem(
            text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Single Mode (Right only)", color = colors.textPrimary)
                    if (currentSendMode == "single") {
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_check),
                            contentDescription = "Selected",
                            tint = colors.accent
                        )
                    }
                }
            },
            onClick = {
                onSelectSendMode("single")
                onDismissRequest()
            }
        )

        DropdownMenuItem(
            text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Mingle Mode (Ask each time)", color = colors.textPrimary)
                    if (currentSendMode == "mingle") {
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_check),
                            contentDescription = "Selected",
                            tint = colors.accent
                        )
                    }
                }
            },
            onClick = {
                onSelectSendMode("mingle")
                onDismissRequest()
            }
        )

        DropdownMenuItem(
            text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Auto Mode (Alternate)", color = colors.textPrimary)
                    if (currentSendMode == "auto") {
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            painter = painterResource(R.drawable.ic_lucide_check),
                            contentDescription = "Selected",
                            tint = colors.accent
                        )
                    }
                }
            },
            onClick = {
                onSelectSendMode("auto")
                onDismissRequest()
            }
        )

        HorizontalDivider(color = colors.border)

        // Show avatars toggle
        DropdownMenuItem(
            text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (showAvatars) "অ্যাভাটার লুকান" else "অ্যাভাটার দেখান", color = colors.textPrimary)
                }
            },
            leadingIcon = {
                Icon(
                    painter = painterResource(R.drawable.ic_lucide_image),
                    contentDescription = null,
                    tint = colors.textSecondary
                )
            },
            onClick = {
                onToggleShowAvatars()
                onDismissRequest()
            }
        )

        // Chat Theme
        DropdownMenuItem(
            text = { Text("চ্যাট থিম কালার", color = colors.textPrimary) },
            leadingIcon = {
                Icon(
                    painter = painterResource(R.drawable.ic_lucide_palette),
                    contentDescription = null,
                    tint = colors.textSecondary
                )
            },
            onClick = {
                onDismissRequest()
                onOpenThemePicker()
            }
        )

        // Reminder for this chat
        DropdownMenuItem(
            text = { Text("এই চ্যাটের জন্য রিমাইন্ডার", color = colors.textPrimary) },
            leadingIcon = {
                Icon(
                    painter = painterResource(R.drawable.ic_lucide_bell),
                    contentDescription = null,
                    tint = colors.textSecondary
                )
            },
            onClick = {
                onDismissRequest()
                onOpenReminderCreation()
            }
        )

        // Chat as PDF / Text
        DropdownMenuItem(
            text = { Text("Chat as PDF / Text", color = colors.textPrimary) },
            leadingIcon = {
                Icon(
                    painter = painterResource(R.drawable.ic_lucide_file_text),
                    contentDescription = null,
                    tint = colors.textSecondary
                )
            },
            onClick = {
                onDismissRequest()
                onExportChatAsDocument()
            }
        )
    }
}
