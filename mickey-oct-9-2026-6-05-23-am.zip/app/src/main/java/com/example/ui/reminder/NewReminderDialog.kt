package com.example.ui.reminder

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Category
import com.example.data.model.Note
import com.example.ui.theme.DeepNoteTheme
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun NewReminderDialog(
    categories: List<Category>,
    defaultCategory: Category? = null,
    defaultNote: Note? = null,
    onDismiss: () -> Unit,
    onSave: (head: String, sub: String, whenTime: Long, sound: String, catId: String?, noteId: String?) -> Unit,
    onPreviewSound: (String) -> Unit
) {
    val colors = DeepNoteTheme.colors
    val context = LocalContext.current

    var header by remember { mutableStateOf(defaultNote?.text?.take(40) ?: "") }
    var subject by remember { mutableStateOf(defaultNote?.text ?: "") }
    var selectedSound by remember { mutableStateOf("bell") } // "beep" | "chime" | "bell" | "alarm"
    var selectedCategory by remember { mutableStateOf<Category?>(defaultCategory) }
    var showCategoryDropdown by remember { mutableStateOf(false) }

    // Target time: default 1 hour from now
    val defaultCal = remember {
        Calendar.getInstance().apply {
            add(Calendar.HOUR_OF_DAY, 1)
        }
    }
    var targetTimeMs by remember { mutableLongStateOf(defaultCal.timeInMillis) }
    var errorText by remember { mutableStateOf<String?>(null) }

    val calendar = remember(targetTimeMs) {
        Calendar.getInstance().apply { timeInMillis = targetTimeMs }
    }

    val dateFormatter = remember { SimpleDateFormat("dd MMM yyyy", Locale("bn")) }
    val timeFormatter = remember { SimpleDateFormat("hh:mm a", Locale("bn")) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = colors.bgSecondary,
        title = {
            Text(
                text = "নতুন রিমাইন্ডার",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = colors.textPrimary
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Header (max 120 chars)
                OutlinedTextField(
                    value = header,
                    onValueChange = {
                        if (it.length <= 120) {
                            header = it
                            errorText = null
                        }
                    },
                    label = { Text("হেডার (যেমন: মিটিং)") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = colors.textPrimary,
                        unfocusedTextColor = colors.textPrimary,
                        focusedBorderColor = colors.accent,
                        unfocusedBorderColor = colors.border
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reminder_header_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Subject (max 500 chars)
                OutlinedTextField(
                    value = subject,
                    onValueChange = { if (it.length <= 500) subject = it },
                    label = { Text("সাবজেক্ট (বিস্তারিত)") },
                    minLines = 2,
                    maxLines = 4,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = colors.textPrimary,
                        unfocusedTextColor = colors.textPrimary,
                        focusedBorderColor = colors.accent,
                        unfocusedBorderColor = colors.border
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("reminder_subject_input")
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Quick buttons: [৫ মিনিট পর] [৩০ মিনিট পর] [১ ঘণ্টা পর] [আগামীকাল ৯টা]
                Text(
                    text = "দ্রুত সময় নির্বাচন:",
                    fontSize = 12.5.sp,
                    color = colors.textSecondary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = false,
                        onClick = {
                            targetTimeMs = System.currentTimeMillis() + 5 * 60 * 1000L
                            errorText = null
                        },
                        label = { Text("৫ মিনিট পর", fontSize = 11.5.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = colors.bgTertiary,
                            labelColor = colors.textPrimary
                        )
                    )

                    FilterChip(
                        selected = false,
                        onClick = {
                            targetTimeMs = System.currentTimeMillis() + 30 * 60 * 1000L
                            errorText = null
                        },
                        label = { Text("৩০ মিনিট পর", fontSize = 11.5.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = colors.bgTertiary,
                            labelColor = colors.textPrimary
                        )
                    )

                    FilterChip(
                        selected = false,
                        onClick = {
                            targetTimeMs = System.currentTimeMillis() + 60 * 60 * 1000L
                            errorText = null
                        },
                        label = { Text("১ ঘণ্টা পর", fontSize = 11.5.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = colors.bgTertiary,
                            labelColor = colors.textPrimary
                        )
                    )

                    FilterChip(
                        selected = false,
                        onClick = {
                            val c = Calendar.getInstance().apply {
                                add(Calendar.DAY_OF_YEAR, 1)
                                set(Calendar.HOUR_OF_DAY, 9)
                                set(Calendar.MINUTE, 0)
                                set(Calendar.SECOND, 0)
                            }
                            targetTimeMs = c.timeInMillis
                            errorText = null
                        },
                        label = { Text("আগামীকাল ৯টা", fontSize = 11.5.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = colors.bgTertiary,
                            labelColor = colors.textPrimary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Date & Time pickers
                Text(
                    text = "তারিখ ও সময়:",
                    fontSize = 12.5.sp,
                    color = colors.textSecondary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            DatePickerDialog(
                                context,
                                { _, year, month, dayOfMonth ->
                                    val newCal = Calendar.getInstance().apply {
                                        timeInMillis = targetTimeMs
                                        set(Calendar.YEAR, year)
                                        set(Calendar.MONTH, month)
                                        set(Calendar.DAY_OF_MONTH, dayOfMonth)
                                    }
                                    targetTimeMs = newCal.timeInMillis
                                    errorText = null
                                },
                                calendar.get(Calendar.YEAR),
                                calendar.get(Calendar.MONTH),
                                calendar.get(Calendar.DAY_OF_MONTH)
                            ).show()
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = dateFormatter.format(Date(targetTimeMs)),
                            fontSize = 12.5.sp,
                            color = colors.textPrimary
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            TimePickerDialog(
                                context,
                                { _, hourOfDay, minute ->
                                    val newCal = Calendar.getInstance().apply {
                                        timeInMillis = targetTimeMs
                                        set(Calendar.HOUR_OF_DAY, hourOfDay)
                                        set(Calendar.MINUTE, minute)
                                        set(Calendar.SECOND, 0)
                                    }
                                    targetTimeMs = newCal.timeInMillis
                                    errorText = null
                                },
                                calendar.get(Calendar.HOUR_OF_DAY),
                                calendar.get(Calendar.MINUTE),
                                false
                            ).show()
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = timeFormatter.format(Date(targetTimeMs)),
                            fontSize = 12.5.sp,
                            color = colors.textPrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Sound picker (বিপ / চাইম / বেল / অ্যালার্ম)
                Text(
                    text = "সাউন্ড নির্বাচন (ট্যাপে প্রিভিউ শুনুন):",
                    fontSize = 12.5.sp,
                    color = colors.textSecondary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val sounds = listOf(
                        "beep" to "বিপ",
                        "chime" to "চাইম",
                        "bell" to "বেল",
                        "alarm" to "অ্যালার্ম"
                    )

                    sounds.forEach { (type, label) ->
                        val isSelected = selectedSound == type
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                selectedSound = type
                                onPreviewSound(type)
                            },
                            label = { Text(label, fontSize = 12.sp) },
                            leadingIcon = {
                                Icon(
                                    painter = painterResource(R.drawable.ic_lucide_volume_2),
                                    contentDescription = null,
                                    modifier = Modifier.size(13.dp)
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = colors.accent,
                                selectedLabelColor = Color.White,
                                containerColor = colors.bgTertiary,
                                labelColor = colors.textPrimary
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Optional link to category
                Text(
                    text = "নোট লিংক (ঐচ্ছিক):",
                    fontSize = 12.5.sp,
                    color = colors.textSecondary
                )
                Spacer(modifier = Modifier.height(6.dp))

                Box {
                    OutlinedButton(
                        onClick = { showCategoryDropdown = true },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = selectedCategory?.name ?: "কোন ক্যাটাগরি সংযুক্ত নেই",
                            fontSize = 12.5.sp,
                            color = if (selectedCategory != null) colors.accentLight else colors.textMuted
                        )
                    }

                    DropdownMenu(
                        expanded = showCategoryDropdown,
                        onDismissRequest = { showCategoryDropdown = false },
                        modifier = Modifier.background(colors.bgSecondary)
                    ) {
                        DropdownMenuItem(
                            text = { Text("কোনটি নয়", color = colors.textSecondary) },
                            onClick = {
                                selectedCategory = null
                                showCategoryDropdown = false
                            }
                        )
                        categories.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat.name, color = colors.textPrimary) },
                                onClick = {
                                    selectedCategory = cat
                                    showCategoryDropdown = false
                                }
                            )
                        }
                    }
                }

                if (errorText != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = errorText!!,
                        fontSize = 12.5.sp,
                        color = colors.danger
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (header.isBlank()) {
                        errorText = "হেডার দিন"
                    } else if (targetTimeMs <= System.currentTimeMillis()) {
                        errorText = "অতীতের সময় দেওয়া যাবে না"
                    } else {
                        onSave(
                            header.trim(),
                            subject.trim(),
                            targetTimeMs,
                            selectedSound,
                            selectedCategory?.id,
                            defaultNote?.id
                        )
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("save_reminder_button")
            ) {
                Text("সেভ করুন", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল", color = colors.textSecondary)
            }
        }
    )
}
