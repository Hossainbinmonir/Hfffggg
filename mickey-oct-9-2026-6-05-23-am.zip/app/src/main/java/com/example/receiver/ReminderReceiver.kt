package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import com.example.alarm.AlarmScheduler
import com.example.alarm.NotificationHelper
import com.example.audio.SoundPlayer
import com.example.data.local.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ReminderReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_FIRE_ALARM = "com.example.deepnote.ACTION_FIRE_ALARM"
        const val ACTION_DISMISS = "com.example.deepnote.ACTION_DISMISS"
        const val ACTION_SNOOZE = "com.example.deepnote.ACTION_SNOOZE"

        const val EXTRA_REMINDER_ID = "extra_reminder_id"
        const val EXTRA_SNOOZE_MINUTES = "extra_snooze_minutes"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val reminderId = intent.getStringExtra(EXTRA_REMINDER_ID) ?: return
        val db = AppDatabase.getInstance(context)

        when (intent.action) {
            ACTION_FIRE_ALARM -> {
                // Acquire temporary wake lock
                val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
                val wakeLock = pm?.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                    "deepnote:reminder_wakelock"
                )
                wakeLock?.acquire(30000)

                CoroutineScope(Dispatchers.IO).launch {
                    val reminder = db.reminderDao().getReminderById(reminderId)
                    if (reminder != null && !reminder.done) {
                        db.reminderDao().updateFired(reminderId, true)
                        NotificationHelper.showReminderNotification(context, reminder)
                        SoundPlayer.startAlarmLoop(context, reminder.sound)
                    }
                    try {
                        if (wakeLock?.isHeld == true) wakeLock.release()
                    } catch (_: Exception) {}
                }
            }
            ACTION_DISMISS -> {
                SoundPlayer.stopAlarmLoop()
                NotificationHelper.cancelNotification(context, reminderId)
                CoroutineScope(Dispatchers.IO).launch {
                    db.reminderDao().updateDone(reminderId, true)
                }
            }
            ACTION_SNOOZE -> {
                val minutes = intent.getIntExtra(EXTRA_SNOOZE_MINUTES, 5)
                SoundPlayer.stopAlarmLoop()
                NotificationHelper.cancelNotification(context, reminderId)
                CoroutineScope(Dispatchers.IO).launch {
                    val newTime = System.currentTimeMillis() + (minutes * 60 * 1000L)
                    db.reminderDao().snooze(reminderId, newTime)
                    val reminder = db.reminderDao().getReminderById(reminderId)
                    if (reminder != null) {
                        AlarmScheduler.scheduleReminder(context, reminder)
                    }
                }
            }
        }
    }
}
