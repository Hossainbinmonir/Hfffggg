package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Reminder
import kotlinx.coroutines.flow.Flow

@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders ORDER BY when_time ASC")
    fun getAllReminders(): Flow<List<Reminder>>

    @Query("SELECT * FROM reminders WHERE done = 0 ORDER BY when_time ASC")
    fun getPendingReminders(): Flow<List<Reminder>>

    @Query("SELECT COUNT(*) FROM reminders WHERE done = 0 AND when_time > :now")
    fun getUpcomingCount(now: Long = System.currentTimeMillis()): Flow<Int>

    @Query("SELECT COUNT(*) FROM reminders WHERE done = 0 AND (fired = 1 OR when_time <= :now)")
    fun getFiredOrDueCount(now: Long = System.currentTimeMillis()): Flow<Int>

    @Query("SELECT * FROM reminders WHERE id = :id LIMIT 1")
    suspend fun getReminderById(id: String): Reminder?

    @Query("SELECT * FROM reminders WHERE id = :id LIMIT 1")
    fun getReminderByIdFlow(id: String): Flow<Reminder?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(reminder: Reminder)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(reminders: List<Reminder>)

    @Update
    suspend fun update(reminder: Reminder)

    @Delete
    suspend fun delete(reminder: Reminder)

    @Query("DELETE FROM reminders WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("UPDATE reminders SET done = :done WHERE id = :id")
    suspend fun updateDone(id: String, done: Boolean)

    @Query("UPDATE reminders SET fired = :fired WHERE id = :id")
    suspend fun updateFired(id: String, fired: Boolean)

    @Query("UPDATE reminders SET when_time = :whenTime, fired = 0, snooze = snooze + 1 WHERE id = :id")
    suspend fun snooze(id: String, whenTime: Long)

    @Query("DELETE FROM reminders")
    suspend fun deleteAll()

    @Query("SELECT * FROM reminders WHERE done = 0 AND when_time > :currentTime")
    suspend fun getPendingToSchedule(currentTime: Long): List<Reminder>

    @Query("SELECT * FROM reminders")
    suspend fun getAllRemindersList(): List<Reminder>
}
