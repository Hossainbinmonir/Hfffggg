package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Category
import kotlinx.coroutines.flow.Flow

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories ORDER BY pin DESC, ord ASC, name ASC")
    fun getAllCategories(): Flow<List<Category>>

    @Query("SELECT * FROM categories WHERE arch = 0 ORDER BY pin DESC, ord ASC, name ASC")
    fun getActiveCategories(): Flow<List<Category>>

    @Query("SELECT * FROM categories WHERE arch = 1 ORDER BY pin DESC, ord ASC, name ASC")
    fun getArchivedCategories(): Flow<List<Category>>

    @Query("SELECT * FROM categories WHERE id = :id LIMIT 1")
    fun getCategoryById(id: String): Flow<Category?>

    @Query("SELECT * FROM categories WHERE id = :id LIMIT 1")
    suspend fun getCategoryByIdOnce(id: String): Category?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(category: Category)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(categories: List<Category>)

    @Update
    suspend fun update(category: Category)

    @Delete
    suspend fun delete(category: Category)

    @Query("DELETE FROM categories WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("UPDATE categories SET ord = :ord WHERE id = :id")
    suspend fun updateOrder(id: String, ord: Int)

    @Query("UPDATE categories SET pin = :pin WHERE id = :id")
    suspend fun updatePinned(id: String, pin: Boolean)

    @Query("UPDATE categories SET arch = :arch WHERE id = :id")
    suspend fun updateArchived(id: String, arch: Boolean)

    @Query("DELETE FROM categories")
    suspend fun deleteAll()

    @Query("SELECT * FROM categories")
    suspend fun getAllCategoriesList(): List<Category>
}
