package com.example.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "deepnote_preferences")

class AppPreferences(private val context: Context) {

    private val KEY_TITLE = stringPreferencesKey("app_title")
    private val KEY_THEME = stringPreferencesKey("app_theme")
    private val KEY_MODE = stringPreferencesKey("send_mode")
    private val KEY_AUTO_COUNTER = intPreferencesKey("auto_counter")
    private val KEY_SHOW_AVATARS = booleanPreferencesKey("show_avatars")
    private val KEY_FONT_SIZE = intPreferencesKey("font_size")
    private val KEY_ACCENT_INDEX = intPreferencesKey("accent_index")
    private val KEY_PIN = stringPreferencesKey("user_pin")
    private val KEY_REMIND_BACKUP = booleanPreferencesKey("remind_backup_7d")
    private val KEY_LAST_BACKUP = longPreferencesKey("last_backup_time")

    val titleFlow: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[KEY_TITLE] ?: "NoteBook"
    }

    val themeFlow: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[KEY_THEME] ?: "dark"
    }

    val modeFlow: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[KEY_MODE] ?: "single"
    }

    val autoCounterFlow: Flow<Int> = context.dataStore.data.map { preferences ->
        preferences[KEY_AUTO_COUNTER] ?: 0
    }

    val showAvatarsFlow: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[KEY_SHOW_AVATARS] ?: true
    }

    val fontSizeFlow: Flow<Int> = context.dataStore.data.map { preferences ->
        preferences[KEY_FONT_SIZE] ?: 1 // 0=small (13sp), 1=medium (15sp), 2=large (17sp)
    }

    val accentIndexFlow: Flow<Int> = context.dataStore.data.map { preferences ->
        preferences[KEY_ACCENT_INDEX] ?: 0 // 0=blue, 1=slate, 2=green, 3=purple
    }

    val pinFlow: Flow<String?> = context.dataStore.data.map { preferences ->
        preferences[KEY_PIN]
    }

    val remindBackupFlow: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[KEY_REMIND_BACKUP] ?: true
    }

    val lastBackupFlow: Flow<Long> = context.dataStore.data.map { preferences ->
        preferences[KEY_LAST_BACKUP] ?: 0L
    }

    suspend fun setTitle(title: String) {
        context.dataStore.edit { it[KEY_TITLE] = title }
    }

    suspend fun setTheme(theme: String) {
        context.dataStore.edit { it[KEY_THEME] = theme }
    }

    suspend fun setMode(mode: String) {
        context.dataStore.edit { it[KEY_MODE] = mode }
    }

    suspend fun incrementAutoCounter(): Int {
        var next = 0
        context.dataStore.edit {
            val current = it[KEY_AUTO_COUNTER] ?: 0
            next = current + 1
            it[KEY_AUTO_COUNTER] = next
        }
        return next
    }

    suspend fun setShowAvatars(show: Boolean) {
        context.dataStore.edit { it[KEY_SHOW_AVATARS] = show }
    }

    suspend fun setFontSize(size: Int) {
        context.dataStore.edit { it[KEY_FONT_SIZE] = size }
    }

    suspend fun setAccentIndex(index: Int) {
        context.dataStore.edit { it[KEY_ACCENT_INDEX] = index }
    }

    suspend fun setPin(pin: String?) {
        context.dataStore.edit {
            if (pin == null) {
                it.remove(KEY_PIN)
            } else {
                it[KEY_PIN] = pin
            }
        }
    }

    suspend fun setRemindBackup(remind: Boolean) {
        context.dataStore.edit { it[KEY_REMIND_BACKUP] = remind }
    }

    suspend fun setLastBackup(time: Long) {
        context.dataStore.edit { it[KEY_LAST_BACKUP] = time }
    }
}
