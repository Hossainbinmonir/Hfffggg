package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "notes",
    foreignKeys = [
        ForeignKey(
            entity = Category::class,
            parentColumns = ["id"],
            childColumns = ["categoryId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["categoryId"])]
)
data class Note(
    @PrimaryKey val id: String,
    val categoryId: String,
    val text: String,
    val side: String = "right", // "left" | "right"
    val image: String? = null,
    val replyTo: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val star: Boolean = false
)
