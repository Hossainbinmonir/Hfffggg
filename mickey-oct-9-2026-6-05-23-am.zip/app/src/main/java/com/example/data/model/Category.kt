package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "categories")
data class Category(
    @PrimaryKey val id: String,
    val name: String,
    val icon: String? = null,
    val img: String? = null,
    val color: String = "#0084FF",
    val themeMine: String? = null,
    val themeOther: String? = null,
    val pin: Boolean = false,
    val arch: Boolean = false,
    val ord: Int = 0
)
