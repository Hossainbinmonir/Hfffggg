package com.example.data.repository

import com.example.data.local.CategoryDao
import com.example.data.local.NoteDao
import com.example.data.local.ReminderDao
import com.example.data.model.BackupData
import com.example.data.model.Category
import com.example.data.model.Note
import com.example.data.model.Reminder
import com.example.data.preferences.AppPreferences
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class DeepNoteRepository(
    private val categoryDao: CategoryDao,
    private val noteDao: NoteDao,
    private val reminderDao: ReminderDao,
    val preferences: AppPreferences
) {
    val activeCategories: Flow<List<Category>> = categoryDao.getActiveCategories()
    val archivedCategories: Flow<List<Category>> = categoryDao.getArchivedCategories()
    val allCategories: Flow<List<Category>> = categoryDao.getAllCategories()

    val allReminders: Flow<List<Reminder>> = reminderDao.getAllReminders()
    val pendingReminders: Flow<List<Reminder>> = reminderDao.getPendingReminders()
    val upcomingCount: Flow<Int> = reminderDao.getUpcomingCount()
    val firedOrDueCount: Flow<Int> = reminderDao.getFiredOrDueCount()

    fun getCategoryById(id: String): Flow<Category?> = categoryDao.getCategoryById(id)
    suspend fun getCategoryByIdOnce(id: String): Category? = categoryDao.getCategoryByIdOnce(id)

    suspend fun createCategory(
        name: String,
        icon: String? = null,
        img: String? = null,
        color: String = "#0084FF",
        themeMine: String? = null,
        themeOther: String? = null
    ): Category {
        val cat = Category(
            id = UUID.randomUUID().toString(),
            name = name,
            icon = icon,
            img = img,
            color = color,
            themeMine = themeMine,
            themeOther = themeOther,
            pin = false,
            arch = false,
            ord = 0
        )
        categoryDao.insert(cat)
        return cat
    }

    suspend fun updateCategory(category: Category) = categoryDao.update(category)
    suspend fun deleteCategory(category: Category) {
        noteDao.deleteForCategory(category.id)
        categoryDao.delete(category)
    }

    suspend fun togglePin(id: String, currentPin: Boolean) =
        categoryDao.updatePinned(id, !currentPin)

    suspend fun toggleArchive(id: String, currentArch: Boolean) =
        categoryDao.updateArchived(id, !currentArch)

    suspend fun updateCategoryOrder(id: String, ord: Int) =
        categoryDao.updateOrder(id, ord)

    fun getNotesForCategory(categoryId: String): Flow<List<Note>> =
        noteDao.getNotesForCategory(categoryId)

    fun getLastNote(categoryId: String): Flow<Note?> =
        noteDao.getLastNoteForCategory(categoryId)

    fun getNoteCount(categoryId: String): Flow<Int> =
        noteDao.getNoteCountForCategory(categoryId)

    fun searchNotes(query: String): Flow<List<Note>> =
        noteDao.searchNotes(query)

    suspend fun getNoteById(id: String): Note? = noteDao.getNoteById(id)

    suspend fun createNote(
        categoryId: String,
        text: String,
        side: String = "right",
        image: String? = null,
        replyTo: String? = null,
        star: Boolean = false
    ): Note {
        val note = Note(
            id = UUID.randomUUID().toString(),
            categoryId = categoryId,
            text = text,
            side = side,
            image = image,
            replyTo = replyTo,
            timestamp = System.currentTimeMillis(),
            star = star
        )
        noteDao.insert(note)
        return note
    }

    suspend fun updateNote(note: Note) = noteDao.update(note)
    suspend fun deleteNote(note: Note) = noteDao.delete(note)
    suspend fun deleteNotes(ids: List<String>) = noteDao.deleteByIds(ids)
    suspend fun toggleStar(id: String, currentStar: Boolean) =
        noteDao.updateStar(id, !currentStar)

    suspend fun moveNotes(ids: List<String>, targetCategoryId: String) =
        noteDao.moveNotes(ids, targetCategoryId)

    suspend fun createReminder(
        head: String,
        sub: String,
        whenTime: Long,
        sound: String = "bell",
        catId: String? = null,
        noteId: String? = null
    ): Reminder {
        val reminder = Reminder(
            id = UUID.randomUUID().toString(),
            head = head,
            sub = sub,
            whenTime = whenTime,
            sound = sound,
            catId = catId,
            noteId = noteId,
            fired = false,
            done = false,
            snooze = 0,
            created = System.currentTimeMillis()
        )
        reminderDao.insert(reminder)
        return reminder
    }

    suspend fun updateReminder(reminder: Reminder) = reminderDao.update(reminder)
    suspend fun deleteReminder(id: String) = reminderDao.deleteById(id)
    suspend fun setReminderDone(id: String, done: Boolean) = reminderDao.updateDone(id, done)
    suspend fun setReminderFired(id: String, fired: Boolean) = reminderDao.updateFired(id, fired)
    suspend fun snoozeReminder(id: String, minutes: Int) {
        val newTime = System.currentTimeMillis() + (minutes * 60 * 1000L)
        reminderDao.snooze(id, newTime)
    }

    suspend fun getReminderById(id: String): Reminder? = reminderDao.getReminderById(id)

    suspend fun seedInitialDataIfEmpty() {
        val existing = categoryDao.getAllCategoriesList()
        if (existing.isEmpty()) {
            val cat1 = Category(
                id = UUID.randomUUID().toString(),
                name = "ব্যক্তিগত ডায়েরি",
                icon = "book",
                color = "#0084FF",
                pin = true,
                ord = 0
            )
            val cat2 = Category(
                id = UUID.randomUUID().toString(),
                name = "দৈনন্দিন কাজ ও লক্ষ্য",
                icon = "check-circle",
                color = "#2E9E6B",
                pin = false,
                ord = 1
            )
            val cat3 = Category(
                id = UUID.randomUUID().toString(),
                name = "নতুন আইডিয়া ও প্রজেক্ট",
                icon = "lightbulb",
                color = "#7A5AF8",
                pin = false,
                ord = 2
            )
            categoryDao.insertAll(listOf(cat1, cat2, cat3))

            // Seed sample notes
            val note1 = Note(
                id = UUID.randomUUID().toString(),
                categoryId = cat1.id,
                text = "স্বাগতম DeepNote এ! এখানে আপনার ব্যক্তিগত চিন্তা ও নোট চ্যাটের মতো সাজিয়ে রাখুন।",
                side = "left",
                timestamp = System.currentTimeMillis() - 100000
            )
            val note2 = Note(
                id = UUID.randomUUID().toString(),
                categoryId = cat1.id,
                text = "আপনি যেকোনো নোটে [ ] চেকবক্স, *বোল্ড*, _ইটালিক_, #ট্যাগ অথবা লিংক যোগ করতে পারবেন।",
                side = "right",
                timestamp = System.currentTimeMillis() - 50000
            )
            val note3 = Note(
                id = UUID.randomUUID().toString(),
                categoryId = cat2.id,
                text = "[ ] সকালের ওয়ার্কআউট সম্পন্ন করা\n[x] DeepNote ইন্সটল করা\n[ ] প্রয়োজনীয় রিমাইন্ডার সেট করা",
                side = "right",
                timestamp = System.currentTimeMillis() - 20000
            )
            noteDao.insertAll(listOf(note1, note2, note3))
        }
    }

    suspend fun exportBackupJson(): String {
        val categories = categoryDao.getAllCategoriesList()
        val notes = noteDao.getAllNotesList()
        val reminders = reminderDao.getAllRemindersList()

        val root = JSONObject()
        root.put("version", 1)
        root.put("exportedAt", System.currentTimeMillis())

        val catArray = JSONArray()
        for (c in categories) {
            val cObj = JSONObject()
            cObj.put("id", c.id)
            cObj.put("name", c.name)
            cObj.put("icon", c.icon)
            cObj.put("img", c.img)
            cObj.put("color", c.color)
            cObj.put("themeMine", c.themeMine)
            cObj.put("themeOther", c.themeOther)
            cObj.put("pin", c.pin)
            cObj.put("arch", c.arch)
            cObj.put("ord", c.ord)
            catArray.put(cObj)
        }
        root.put("categories", catArray)

        val noteArray = JSONArray()
        for (n in notes) {
            val nObj = JSONObject()
            nObj.put("id", n.id)
            nObj.put("categoryId", n.categoryId)
            nObj.put("text", n.text)
            nObj.put("side", n.side)
            nObj.put("image", n.image)
            nObj.put("replyTo", n.replyTo)
            nObj.put("timestamp", n.timestamp)
            nObj.put("star", n.star)
            noteArray.put(nObj)
        }
        root.put("notes", noteArray)

        val remArray = JSONArray()
        for (r in reminders) {
            val rObj = JSONObject()
            rObj.put("id", r.id)
            rObj.put("head", r.head)
            rObj.put("sub", r.sub)
            rObj.put("whenTime", r.whenTime)
            rObj.put("sound", r.sound)
            rObj.put("catId", r.catId)
            rObj.put("noteId", r.noteId)
            rObj.put("fired", r.fired)
            rObj.put("done", r.done)
            rObj.put("snooze", r.snooze)
            rObj.put("created", r.created)
            remArray.put(rObj)
        }
        root.put("reminders", remArray)

        return root.toString(2)
    }

    suspend fun importBackupJson(jsonString: String): Result<Int> {
        return try {
            val root = JSONObject(jsonString)
            val catArray = root.optJSONArray("categories") ?: JSONArray()
            val noteArray = root.optJSONArray("notes") ?: JSONArray()
            val remArray = root.optJSONArray("reminders") ?: JSONArray()

            val newCategories = mutableListOf<Category>()
            for (i in 0 until catArray.length()) {
                val obj = catArray.getJSONObject(i)
                newCategories.add(
                    Category(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        icon = if (obj.has("icon") && !obj.isNull("icon")) obj.getString("icon") else null,
                        img = if (obj.has("img") && !obj.isNull("img")) obj.getString("img") else null,
                        color = obj.optString("color", "#0084FF"),
                        themeMine = if (obj.has("themeMine") && !obj.isNull("themeMine")) obj.getString("themeMine") else null,
                        themeOther = if (obj.has("themeOther") && !obj.isNull("themeOther")) obj.getString("themeOther") else null,
                        pin = obj.optBoolean("pin", false),
                        arch = obj.optBoolean("arch", false),
                        ord = obj.optInt("ord", 0)
                    )
                )
            }

            val newNotes = mutableListOf<Note>()
            for (i in 0 until noteArray.length()) {
                val obj = noteArray.getJSONObject(i)
                newNotes.add(
                    Note(
                        id = obj.getString("id"),
                        categoryId = obj.getString("categoryId"),
                        text = obj.getString("text"),
                        side = obj.optString("side", "right"),
                        image = if (obj.has("image") && !obj.isNull("image")) obj.getString("image") else null,
                        replyTo = if (obj.has("replyTo") && !obj.isNull("replyTo")) obj.getString("replyTo") else null,
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        star = obj.optBoolean("star", false)
                    )
                )
            }

            val newReminders = mutableListOf<Reminder>()
            for (i in 0 until remArray.length()) {
                val obj = remArray.getJSONObject(i)
                newReminders.add(
                    Reminder(
                        id = obj.getString("id"),
                        head = obj.getString("head"),
                        sub = obj.optString("sub", ""),
                        whenTime = obj.getLong("whenTime"),
                        sound = obj.optString("sound", "bell"),
                        catId = if (obj.has("catId") && !obj.isNull("catId")) obj.getString("catId") else null,
                        noteId = if (obj.has("noteId") && !obj.isNull("noteId")) obj.getString("noteId") else null,
                        fired = obj.optBoolean("fired", false),
                        done = obj.optBoolean("done", false),
                        snooze = obj.optInt("snooze", 0),
                        created = obj.optLong("created", System.currentTimeMillis())
                    )
                )
            }

            // Replace all data
            categoryDao.deleteAll()
            noteDao.deleteAll()
            reminderDao.deleteAll()

            categoryDao.insertAll(newCategories)
            noteDao.insertAll(newNotes)
            reminderDao.insertAll(newReminders)

            preferences.setLastBackup(System.currentTimeMillis())
            Result.success(newCategories.size)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun exportAllNotesAsText(): String {
        val categories = categoryDao.getAllCategoriesList()
        val notes = noteDao.getAllNotesList().groupBy { it.categoryId }
        val sb = StringBuilder()
        sb.append("DeepNote — সকল নোট ব্যাকআপ\n")
        sb.append("তারিখ: ").append(java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date())).append("\n\n")

        for (c in categories) {
            sb.append("========================================\n")
            sb.append("ক্যাটাগরি: ").append(c.name).append("\n")
            sb.append("========================================\n\n")
            val catNotes = notes[c.id] ?: emptyList()
            if (catNotes.isEmpty()) {
                sb.append("(কোন নোট নেই)\n\n")
            } else {
                for (n in catNotes) {
                    val dateStr = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date(n.timestamp))
                    sb.append("• [").append(dateStr).append("] ")
                    if (n.star) sb.append("★ ")
                    sb.append(n.text).append("\n\n")
                }
            }
        }
        return sb.toString()
    }
}
