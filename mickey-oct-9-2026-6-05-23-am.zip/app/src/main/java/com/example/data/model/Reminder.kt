package com.example.data.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey val id: String,
    val head: String,
    val sub: String,
    @ColumnInfo(name = "when_time") val whenTime: Long,
    val sound: String = "bell", // "beep" | "chime" | "bell" | "alarm"
    val catId: String? = null,
    val noteId: String? = null,
    val fired: Boolean = false,
    val done: Boolean = false,
    val snooze: Int = 0,
    val created: Long = System.currentTimeMillis()
)
