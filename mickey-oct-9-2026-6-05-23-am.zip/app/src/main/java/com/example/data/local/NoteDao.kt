package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Note
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes WHERE categoryId = :categoryId ORDER BY timestamp ASC")
    fun getNotesForCategory(categoryId: String): Flow<List<Note>>

    @Query("SELECT * FROM notes ORDER BY timestamp DESC")
    fun getAllNotes(): Flow<List<Note>>

    @Query("SELECT * FROM notes WHERE text LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    fun searchNotes(query: String): Flow<List<Note>>

    @Query("SELECT * FROM notes WHERE id = :id LIMIT 1")
    suspend fun getNoteById(id: String): Note?

    @Query("SELECT * FROM notes WHERE categoryId = :categoryId ORDER BY timestamp DESC LIMIT 1")
    fun getLastNoteForCategory(categoryId: String): Flow<Note?>

    @Query("SELECT COUNT(*) FROM notes WHERE categoryId = :categoryId")
    fun getNoteCountForCategory(categoryId: String): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(note: Note)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(notes: List<Note>)

    @Update
    suspend fun update(note: Note)

    @Delete
    suspend fun delete(note: Note)

    @Query("DELETE FROM notes WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<String>)

    @Query("DELETE FROM notes WHERE categoryId = :categoryId")
    suspend fun deleteForCategory(categoryId: String)

    @Query("UPDATE notes SET star = :star WHERE id = :id")
    suspend fun updateStar(id: String, star: Boolean)

    @Query("UPDATE notes SET categoryId = :newCategoryId WHERE id IN (:ids)")
    suspend fun moveNotes(ids: List<String>, newCategoryId: String)

    @Query("DELETE FROM notes")
    suspend fun deleteAll()

    @Query("SELECT * FROM notes")
    suspend fun getAllNotesList(): List<Note>
}
